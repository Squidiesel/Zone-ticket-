export type MarketName = "Forex" | "Commodities" | "Indices" | "Crypto" | "ETFs" | "Stocks";
export type Kind = "stock" | "forex" | "commodity" | "index" | "crypto";
export type Acct = "AUD" | "USD";
export type Dir = "All" | "Long" | "Short";
export type SortBy = "Best setup" | "Reward:risk" | "Closest to entry" | "Market";

export interface Settings {
  acct: Acct;
  equity: number;
  risk_pct: number;
  sel: MarketName[];
  watch: string;
  extras: string;
  show_close: boolean;
  auto: boolean;
  sort_by: SortBy;
  dir_f: Dir;
  min_rr: number;
  alerts_on: boolean;
  ntfy_topic: string;
  min_score: number;
  min_rr_take: number;
  max_dist: number;
  per_inst: number;
  f_events: boolean;
  ev_min: number;
  manual_ev: string;
  f_news: boolean;
  news_hrs: number;
  f_earn: boolean;
  f_rvol: boolean;
  rv_weak: number;
  f_vwap: boolean;
  vwap_tol: number;
  f_htf: boolean;
  f_index: boolean;
  max_spread: number;
  f_depart: boolean;
  zq_depart: number;
  f_age: boolean;
  zq_age: number;
  f_nest: boolean;
  f_react: boolean;
  f_stale: boolean;
  stale_min: number;
  f_limits: boolean;
  day_loss_pct: number;
  max_open: number;
  max_open_risk: number;
  lev_Forex: number;
  lev_Commodities: number;
  lev_Indices: number;
  lev_Crypto: number;
  lev_ETFs: number;
  lev_Stocks: number;
}

export const SORTS: SortBy[] = ["Best setup", "Reward:risk", "Closest to entry", "Market"];
export const DIRS: Dir[] = ["All", "Long", "Short"];
export const US_MARKETS: MarketName[] = ["Stocks", "ETFs"];

export const DEFAULT_WATCH =
  "AAPL MSFT NVDA AMD TSLA META AMZN GOOGL NFLX AVGO PLTR SMCI COIN MSTR HOOD SOFI " +
  "RKLB ASTS LUNR IONQ RGTI AVAV KTOS MRNA CRSP " +
  "MU INTC ARM TSM ORCL CRM ADBE UBER SHOP SNOW CRWD PANW ANET PYPL AFRM UPST RBLX U DKNG " +
  "ABNB DASH RIVN LCID NIO F BA DIS NKE JPM BAC GS XOM CVX OXY LLY UNH WMT COST " +
  "MARA RIOT CLSK SNAP ROKU";

type MarketSpec = { kind: Kind; lev: number; symbols: [string, string][] };

export const MARKETS: Record<MarketName, MarketSpec> = {
  Forex: {
    kind: "forex",
    lev: 30,
    symbols: [
      ["EURUSD=X", "EUR/USD"], ["GBPUSD=X", "GBP/USD"], ["USDJPY=X", "USD/JPY"],
      ["AUDUSD=X", "AUD/USD"], ["NZDUSD=X", "NZD/USD"], ["USDCAD=X", "USD/CAD"],
      ["USDCHF=X", "USD/CHF"], ["EURJPY=X", "EUR/JPY"], ["GBPJPY=X", "GBP/JPY"],
      ["AUDJPY=X", "AUD/JPY"], ["EURGBP=X", "EUR/GBP"], ["EURAUD=X", "EUR/AUD"],
      ["AUDNZD=X", "AUD/NZD"], ["AUDCAD=X", "AUD/CAD"], ["AUDCHF=X", "AUD/CHF"],
      ["EURCAD=X", "EUR/CAD"], ["EURCHF=X", "EUR/CHF"], ["EURNZD=X", "EUR/NZD"],
      ["GBPAUD=X", "GBP/AUD"], ["GBPCAD=X", "GBP/CAD"], ["GBPCHF=X", "GBP/CHF"],
      ["GBPNZD=X", "GBP/NZD"], ["NZDJPY=X", "NZD/JPY"], ["CADJPY=X", "CAD/JPY"],
      ["CHFJPY=X", "CHF/JPY"], ["NZDCAD=X", "NZD/CAD"], ["CADCHF=X", "CAD/CHF"],
    ],
  },
  Commodities: {
    kind: "commodity",
    lev: 10,
    symbols: [
      ["GC=F", "Gold"], ["SI=F", "Silver"], ["PL=F", "Platinum"], ["HG=F", "Copper"],
      ["CL=F", "WTI Oil"], ["BZ=F", "Brent Oil"], ["NG=F", "Natural Gas"],
      ["ZW=F", "Wheat"], ["ZC=F", "Corn"], ["KC=F", "Coffee"],
      ["PA=F", "Palladium"], ["HO=F", "Heating Oil"], ["RB=F", "Gasoline"],
      ["ZS=F", "Soybeans"], ["ZL=F", "Soybean Oil"], ["SB=F", "Sugar"],
      ["CC=F", "Cocoa"], ["CT=F", "Cotton"], ["LE=F", "Live Cattle"], ["HE=F", "Lean Hogs"],
    ],
  },
  Indices: {
    kind: "index",
    lev: 20,
    symbols: [
      ["ES=F", "S&P 500"], ["NQ=F", "Nasdaq 100"], ["YM=F", "Dow Jones"], ["RTY=F", "Russell 2000"],
      ["^GDAXI", "Germany 40"], ["^FTSE", "UK 100"], ["^N225", "Japan 225"],
      ["^AXJO", "Australia 200"], ["^HSI", "Hong Kong 50"],
      ["^FCHI", "France 40"], ["^STOXX50E", "Euro Stoxx 50"], ["^IXIC", "Nasdaq Composite"],
      ["^RUT", "Russell 2000 Index"],
    ],
  },
  Crypto: {
    kind: "crypto",
    lev: 2,
    symbols: [
      ["BTC-USD", "Bitcoin"], ["ETH-USD", "Ethereum"], ["SOL-USD", "Solana"],
      ["XRP-USD", "XRP"], ["DOGE-USD", "Dogecoin"], ["ADA-USD", "Cardano"],
      ["BNB-USD", "BNB"], ["AVAX-USD", "Avalanche"], ["LINK-USD", "Chainlink"],
      ["LTC-USD", "Litecoin"], ["DOT-USD", "Polkadot"], ["TRX-USD", "Tron"],
      ["BCH-USD", "Bitcoin Cash"], ["SHIB-USD", "Shiba Inu"],
    ],
  },
  ETFs: {
    kind: "index",
    lev: 5,
    symbols: [
      ["SPY", "SPY"], ["QQQ", "QQQ"], ["IWM", "IWM"], ["DIA", "DIA"], ["TQQQ", "TQQQ"],
      ["SQQQ", "SQQQ"], ["SOXL", "SOXL"], ["GLD", "GLD"], ["SLV", "SLV"], ["TLT", "TLT"],
      ["SMH", "SMH"], ["XLK", "XLK"], ["XLF", "XLF"], ["XLE", "XLE"], ["XLV", "XLV"],
      ["XLY", "XLY"], ["XLI", "XLI"], ["ARKK", "ARKK"], ["XBI", "XBI"], ["EEM", "EEM"],
      ["FXI", "FXI"], ["USO", "USO"], ["UNG", "UNG"], ["TNA", "TNA"], ["SPXL", "SPXL"],
      ["LABU", "LABU"], ["IBIT", "IBIT"], ["UVXY", "UVXY"],
    ],
  },
  Stocks: { kind: "stock", lev: 5, symbols: [] },
};

export const MARKET_NAMES = Object.keys(MARKETS) as MarketName[];

export const INDEX_CCY: Record<string, string> = {
  "^GDAXI": "EUR", "^FTSE": "GBP", "^N225": "JPY", "^AXJO": "AUD", "^HSI": "HKD",
  "^FCHI": "EUR", "^STOXX50E": "EUR",
};

const LOOKUP = new Map<string, [string, Kind, MarketName]>();
for (const m of MARKET_NAMES) {
  for (const [sym, label] of MARKETS[m].symbols) LOOKUP.set(sym, [label, MARKETS[m].kind, m]);
}

export function infer(sym: string): [string, Kind, MarketName] {
  const hit = LOOKUP.get(sym);
  if (hit) return hit;
  if (sym.endsWith("=X")) return [sym, "forex", "Forex"];
  if (sym.endsWith("=F")) return [sym, "commodity", "Commodities"];
  if (sym.endsWith("-USD")) return [sym, "crypto", "Crypto"];
  if (sym.startsWith("^")) return [sym, "index", "Indices"];
  return [sym, "stock", "Stocks"];
}

export function isUsMarket(market: string): boolean {
  return market === "Stocks" || market === "ETFs";
}

function levDefaults(): Pick<
  Settings,
  "lev_Forex" | "lev_Commodities" | "lev_Indices" | "lev_Crypto" | "lev_ETFs" | "lev_Stocks"
> {
  return {
    lev_Forex: MARKETS.Forex.lev,
    lev_Commodities: MARKETS.Commodities.lev,
    lev_Indices: MARKETS.Indices.lev,
    lev_Crypto: MARKETS.Crypto.lev,
    lev_ETFs: MARKETS.ETFs.lev,
    lev_Stocks: MARKETS.Stocks.lev,
  };
}

export const DEFAULTS: Settings = {
  acct: "AUD",
  equity: 10000,
  risk_pct: 2,
  // Crypto only until you add markets. A full book is a long scan and Yahoo will push back.
  sel: ["Crypto"],
  watch: DEFAULT_WATCH,
  extras: "",
  show_close: false,
  auto: false,
  sort_by: "Best setup",
  dir_f: "All",
  min_rr: 0,
  alerts_on: false,
  ntfy_topic: "",
  min_score: 3,
  min_rr_take: 2.5,
  max_dist: 15,
  per_inst: 3,
  f_events: true,
  ev_min: 15,
  manual_ev: "",
  f_news: true,
  news_hrs: 3,
  f_earn: true,
  f_rvol: true,
  rv_weak: 0.8,
  f_vwap: true,
  vwap_tol: 1,
  f_htf: true,
  f_index: true,
  max_spread: 0.05,
  f_depart: true,
  zq_depart: 3,
  f_age: true,
  zq_age: 96,
  f_nest: true,
  f_react: false,
  f_stale: true,
  stale_min: 60,
  f_limits: true,
  day_loss_pct: 6,
  max_open: 3,
  max_open_risk: 6,
  ...levDefaults(),
};

export const BOUNDS: Record<string, [number, number]> = {
  equity: [100, 1e9],
  risk_pct: [0.1, 10],
  min_rr: [0, 20],
  ev_min: [0, 120],
  news_hrs: [0.5, 24],
  rv_weak: [0.1, 2],
  max_spread: [0, 2],
  vwap_tol: [0, 5],
  zq_depart: [2, 10],
  zq_age: [4, 120],
  stale_min: [5, 2880],
  day_loss_pct: [0.5, 50],
  max_open: [1, 50],
  max_open_risk: [0.5, 100],
  min_score: [1, 5],
  min_rr_take: [1, 10],
  max_dist: [2, 40],
  per_inst: [1, 6],
  lev_Forex: [1, 500],
  lev_Commodities: [1, 500],
  lev_Indices: [1, 500],
  lev_Crypto: [1, 500],
  lev_ETFs: [1, 500],
  lev_Stocks: [1, 500],
};

export function clampKey(key: string, v: number): number {
  const b = BOUNDS[key];
  if (!b || !Number.isFinite(v)) return v;
  return Math.min(b[1], Math.max(b[0], v));
}

export function levOf(S: Settings, market: string): number {
  const v = S[`lev_${market}` as keyof Settings];
  return typeof v === "number" && Number.isFinite(v) ? v : 5;
}

export type Job = { sym: string; label: string; market: string; kind: Kind };

export function buildJobs(S: Settings): Job[] {
  const jobs: Job[] = [];
  const seen = new Set<string>();
  const add = (sym: string, label: string, market: string, kind: Kind) => {
    const s = sym.trim().toUpperCase();
    if (!s || seen.has(s)) return;
    seen.add(s);
    jobs.push({ sym: s, label, market, kind });
  };
  for (const m of S.sel) {
    const spec = MARKETS[m];
    if (!spec) continue;
    if (m === "Stocks") {
      for (const sym of S.watch.replace(/,/g, " ").toUpperCase().split(/\s+/)) {
        if (sym) add(sym, sym, m, spec.kind);
      }
    } else {
      for (const [sym, label] of spec.symbols) add(sym, label, m, spec.kind);
    }
  }
  for (const sym of S.extras.replace(/,/g, " ").toUpperCase().split(/\s+/)) {
    if (!sym) continue;
    const [label, kind, market] = infer(sym);
    add(sym, label, market, kind);
  }
  return jobs;
}

const CODE_PREFIX = "ZT1:";

function bytesToB64Url(bytes: Uint8Array): string {
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function b64UrlToString(s: string): string {
  const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
  const bin = atob(s.replace(/-/g, "+").replace(/_/g, "/") + pad);
  const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
  return new TextDecoder().decode(bytes);
}

export function settingsToCode(settings: Settings): string {
  const data: Record<string, unknown> = {};
  for (const k of Object.keys(DEFAULTS) as (keyof Settings)[]) data[k] = settings[k];
  const raw = JSON.stringify(data);
  return CODE_PREFIX + bytesToB64Url(new TextEncoder().encode(raw));
}

function cleanSetting(key: keyof Settings, v: unknown): Settings[keyof Settings] | undefined {
  const d = DEFAULTS[key];
  if (typeof d === "boolean") return typeof v === "boolean" ? v : undefined;
  if (typeof d === "number") {
    if (typeof v === "boolean" || typeof v !== "number" || !Number.isFinite(v)) return undefined;
    return clampKey(key, v);
  }
  if (Array.isArray(d)) {
    if (!Array.isArray(v)) return undefined;
    return v.filter((x): x is MarketName => typeof x === "string" && x in MARKETS);
  }
  if (typeof v !== "string") return undefined;
  if (key === "acct" && v !== "AUD" && v !== "USD") return undefined;
  if (key === "sort_by" && !SORTS.includes(v as SortBy)) return undefined;
  if (key === "dir_f" && !DIRS.includes(v as Dir)) return undefined;
  return v.slice(0, 4000) as Settings[keyof Settings];
}

export function codeToSettings(code: string): Partial<Settings> {
  const trimmed = (code || "").trim();
  if (!trimmed.startsWith(CODE_PREFIX)) throw new Error("That does not look like a settings code.");
  let data: unknown;
  try {
    data = JSON.parse(b64UrlToString(trimmed.slice(CODE_PREFIX.length)));
  } catch {
    throw new Error("The code is damaged.");
  }
  if (!data || typeof data !== "object" || Array.isArray(data)) throw new Error("The code is damaged.");
  const out: Partial<Settings> = {};
  for (const [k, v] of Object.entries(data)) {
    if (!(k in DEFAULTS)) continue;
    const clean = cleanSetting(k as keyof Settings, v);
    if (clean !== undefined) (out as Record<string, unknown>)[k] = clean;
  }
  if (!Object.keys(out).length) throw new Error("The code has no usable settings.");
  return out;
}

export const TOPIC_RE = /^[A-Za-z0-9_-]{6,64}$/;
export function validTopic(topic: string): boolean {
  return TOPIC_RE.test((topic || "").trim());
}

export const CHECK_WHY: Record<string, string> = {
  "Passes the screen": "Thin, cheap or flat instruments have wide spreads and do not travel far enough to pay for the risk.",
  "Zone score": "Five quality points: strong departure, untouched, tight base, higher timeframes agree, volume or momentum. More points means the zone is more likely to still hold unfilled orders.",
  "Reward : risk": "At 2.5 to 1 you can lose well over half your trades and still make money. Low reward to risk needs a very high win rate.",
  "Affordable size": "If your risk amount cannot buy a single unit, the stop is too wide for your account size.",
  "Leverage within limit": "The trade must fit the leverage your broker allows, or it cannot be placed.",
  "Margin under 50%": "Tying up more than half your equity in margin leaves no room for a second trade or a bad move.",
  "Fresh data": "If the last candle is old the market is closed or the feed is lagging, so the levels are not live.",
  "No news event nearby": "Rate decisions and big data releases blow out spreads and run straight through zones.",
  Spread: "A wide bid-ask spread is a cost paid on entry and exit, and it eats a tight stop.",
  "No earnings risk": "Earnings cause overnight gaps that jump past your stop with no chance to exit.",
  "No bad headline": "Fresh bad news against a long (or good news against a short) can overrun a zone.",
  "Volume at the zone": "A zone with no volume when price arrives has no real buyers or sellers defending it.",
  "Index calm": "US stocks follow SPY and QQQ. A long into an index selloff usually gets dragged through its zone.",
  "VWAP side": "VWAP is the day's average price. Buying far below it or shorting far above it fights the day's balance.",
  "1h trend agrees": "Trading with the hourly structure means you are not fighting the bigger move.",
  "Strong departure": "A zone that price left slowly had little imbalance behind it, so it is less likely to hold.",
  "Young zone": "Old zones have been seen and traded by more people and tend to be used up.",
  "Not nested": "A bigger opposing zone around your entry can stop price before it reaches your target.",
  "Rejection candle": "Waiting for a wick or engulfing candle shows the zone is actually holding right now. This turns plays into watch-only until price arrives, so it is off by default.",
  "Within your trading limits": "Daily loss, open trade count and total open risk limits stop one bad day from getting out of control.",
};
