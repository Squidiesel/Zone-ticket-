import { createServerFn } from "@tanstack/react-start";

import type { Kind } from "@/lib/zone/markets";
import type { ContextPayload, SymbolResult } from "@/lib/zone/yahoo.server";

export type { ContextPayload, SymbolResult };

const KINDS = new Set<Kind>(["stock", "forex", "commodity", "index", "crypto"]);

type JobIn = { sym: string; label: string; market: string; kind: Kind };

function parseJobs(data: unknown): {
  jobs: JobIn[];
  maxDist: number;
  minScore: number;
  minRr: number;
  perInst: number;
  maxSpread: number;
} {
  if (!data || typeof data !== "object") throw new Error("Bad scan request.");
  const o = data as Record<string, unknown>;
  const jobsIn = Array.isArray(o.jobs) ? o.jobs : [];
  const jobs: JobIn[] = [];
  for (const j of jobsIn.slice(0, 4)) {
    if (!j || typeof j !== "object") continue;
    const row = j as Record<string, unknown>;
    const sym = String(row.sym ?? "").trim().toUpperCase().slice(0, 32);
    if (!/^[A-Z0-9.^=-]{1,32}$/.test(sym)) continue;
    const kind = String(row.kind ?? "stock") as Kind;
    if (!KINDS.has(kind)) continue;
    jobs.push({
      sym,
      label: String(row.label ?? sym).slice(0, 48),
      market: String(row.market ?? "").slice(0, 32),
      kind,
    });
  }
  const num = (v: unknown, d: number, lo: number, hi: number) => {
    const n = typeof v === "number" ? v : Number(v);
    if (!Number.isFinite(n)) return d;
    return Math.min(hi, Math.max(lo, n));
  };
  return {
    jobs,
    maxDist: num(o.maxDist, 15, 2, 40),
    minScore: num(o.minScore, 3, 1, 5),
    minRr: num(o.minRr, 2.5, 1, 10),
    perInst: num(o.perInst, 3, 1, 6),
    maxSpread: num(o.maxSpread, 0.05, 0, 2),
  };
}

export const scanBatchFn = createServerFn({ method: "POST" })
  .validator((data: unknown) => parseJobs(data))
  .handler(async ({ data }) => {
    const { scanBatch } = await import("./yahoo.server");
    return scanBatch(data.jobs, {
      maxDist: data.maxDist,
      minScore: data.minScore,
      minRr: data.minRr,
      perInst: data.perInst,
      maxSpread: data.maxSpread,
    });
  });

export const loadContextFn = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const o = (data && typeof data === "object" ? data : {}) as Record<string, unknown>;
    return {
      manual: String(o.manual ?? "").slice(0, 4000),
      fmpKey: String(o.fmpKey ?? "").trim().slice(0, 80),
    };
  })
  .handler(async ({ data }): Promise<ContextPayload> => {
    const { loadContext } = await import("./yahoo.server");
    return loadContext(data.manual, data.fmpKey);
  });

export const sendAlertFn = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const o = (data && typeof data === "object" ? data : {}) as Record<string, unknown>;
    return {
      topic: String(o.topic ?? "").trim().slice(0, 64),
      title: String(o.title ?? "Zone Ticket").slice(0, 120),
      body: String(o.body ?? "").slice(0, 3500),
    };
  })
  .handler(async ({ data }) => {
    const { sendNtfy } = await import("./yahoo.server");
    await sendNtfy(data.topic, data.title, data.body, "high");
    return { ok: true as const };
  });
