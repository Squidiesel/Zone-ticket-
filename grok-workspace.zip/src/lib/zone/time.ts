/** Clocks and cache lifetimes. New York decides the US cash session, not the phone's offset. */

export const NY = "America/New_York";
export const SYD = "Australia/Sydney";

export type Zoned = { weekday: string; ymd: string; minutes: number };

export function zonedParts(date: Date, timeZone: string): Zoned {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    weekday: "short",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);
  const g = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  let hour = Number(g("hour"));
  if (hour === 24) hour = 0;
  const minute = Number(g("minute"));
  return {
    weekday: g("weekday"),
    ymd: `${g("year")}-${g("month")}-${g("day")}`,
    minutes: hour * 60 + minute,
  };
}

export function ymd(ts: number, timeZone: string): string {
  return zonedParts(new Date(ts), timeZone).ymd;
}

export function minutesOfDay(ts: number, timeZone: string): number {
  return zonedParts(new Date(ts), timeZone).minutes;
}

/** Weekday 9:30–16:00 America/New_York. A weekend clock is never "open". */
export function usCashSessionOpen(now = new Date()): boolean {
  const p = zonedParts(now, NY);
  if (p.weekday === "Sat" || p.weekday === "Sun") return false;
  return p.minutes >= 9 * 60 + 30 && p.minutes < 16 * 60;
}

export function isNyWeekend(now = new Date()): boolean {
  const w = zonedParts(now, NY).weekday;
  return w === "Sat" || w === "Sun";
}

/**
 * How long a price series may be reused.
 * Crypto stays short so a breakout is not judged on a three-minute-old print.
 * US names rest longer once the cash session is shut, which also cuts Yahoo traffic.
 */
export function priceTtlMs(kind: string, now = new Date()): number {
  if (kind === "crypto") return 45_000;
  if (kind === "forex") return 90_000;
  if (kind === "commodity") return 120_000;
  return usCashSessionOpen(now) ? 180_000 : 15 * 60_000;
}

export function priceTtlLabel(now = new Date()): string {
  const us = usCashSessionOpen(now) ? "3 min while New York is open" : "15 min while New York is closed";
  return `Crypto 45s · forex 90s · commodities 2 min · US stocks and ETFs ${us}`;
}

const ISO_RE =
  /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,9}))?)?(Z|[+-]\d{2}:?\d{2})?)?$/;

/** Never throws. Rejects junk from a hand-edited journal file. */
export function parseIso(v: unknown): Date | null {
  if (typeof v !== "string") return null;
  const s = v.trim();
  if (!s || s.length > 40) return null;
  const m = ISO_RE.exec(s);
  if (!m) return null;
  const y = Number(m[1]);
  const mo = Number(m[2]);
  const da = Number(m[3]);
  if (mo < 1 || mo > 12 || da < 1 || da > 31) return null;
  if (m[4] != null && (Number(m[4]) > 23 || Number(m[5]) > 59)) return null;
  const iso = m[4] == null ? `${m[1]}-${m[2]}-${m[3]}T00:00:00Z` : s.includes(" ") ? s.replace(" ", "T") : s;
  const hasZone = /(?:Z|[+-]\d{2}:?\d{2})$/.test(iso);
  const d = new Date(hasZone ? iso : `${iso}Z`);
  if (Number.isNaN(d.getTime())) return null;
  return d;
}

export function zonedLocalToUtc(
  timeZone: string,
  ymdText: string,
  hour: number,
  minute: number,
): Date | null {
  const [ys, ms, ds] = ymdText.split("-").map(Number);
  if (!ys || !ms || !ds || hour > 23 || minute > 59 || hour < 0 || minute < 0) return null;
  for (let offset = -14; offset <= 14; offset++) {
    const d = new Date(Date.UTC(ys, ms - 1, ds, hour - offset, minute, 0));
    const p = zonedParts(d, timeZone);
    if (p.ymd === ymdText && p.minutes === hour * 60 + minute) return d;
  }
  return null;
}

export function prevBday(ymdText: string): string {
  let cursor = Date.parse(`${ymdText}T17:00:00Z`);
  if (Number.isNaN(cursor)) return ymdText;
  for (let i = 0; i < 6; i++) {
    cursor -= 86_400_000;
    const p = zonedParts(new Date(cursor), NY);
    if (p.weekday !== "Sat" && p.weekday !== "Sun") return p.ymd;
  }
  return ymdText;
}

export function nextUsOpen(now = new Date()): Date | null {
  const today = zonedParts(now, NY);
  if (today.weekday !== "Sat" && today.weekday !== "Sun") {
    const openToday = zonedLocalToUtc(NY, today.ymd, 9, 30);
    if (openToday && now.getTime() < openToday.getTime()) return openToday;
  }
  let cursor = Date.parse(`${today.ymd}T17:00:00Z`);
  if (Number.isNaN(cursor)) return null;
  for (let i = 0; i < 8; i++) {
    cursor += 86_400_000;
    const p = zonedParts(new Date(cursor), NY);
    if (p.weekday === "Sat" || p.weekday === "Sun") continue;
    return zonedLocalToUtc(NY, p.ymd, 9, 30);
  }
  return null;
}

export function fmtZone(
  ts: number,
  timeZone: string,
  opts?: { weekday?: boolean; day?: boolean },
): string {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone,
    weekday: opts?.weekday === false ? undefined : "short",
    day: opts?.day ? "2-digit" : undefined,
    month: opts?.day ? "short" : undefined,
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(new Date(ts));
  const g = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  let hour = g("hour");
  if (hour === "24") hour = "00";
  const hm = `${hour.padStart(2, "0")}:${g("minute").padStart(2, "0")}`;
  return [g("weekday"), opts?.day ? `${g("day")} ${g("month")}` : "", hm].filter(Boolean).join(" ");
}

export function fmtAge(mins: number): string {
  if (mins < 90) return `${Math.max(mins, 0).toFixed(0)} min`;
  if (mins < 48 * 60) return `${(mins / 60).toFixed(1)} h`;
  return `${(mins / 1440).toFixed(1)} days`;
}
