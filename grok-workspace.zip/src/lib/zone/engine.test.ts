import assert from "node:assert/strict";

import { TtlCache } from "@/lib/zone/cache";
import { buildPlays, findZones, indexFlags, limitState, tradesFromCsv, type Bar } from "@/lib/zone/engine";
import { DEFAULTS, codeToSettings, settingsToCode } from "@/lib/zone/markets";
import { parseIso, priceTtlMs, usCashSessionOpen } from "@/lib/zone/time";

function flat(n: number, px = 100): Bar[] {
  const start = Date.parse("2026-10-01T13:30:00Z");
  return Array.from({ length: n }, (_, i) => ({
    t: start + i * 15 * 60_000,
    o: px,
    h: px + 0.6,
    l: px - 0.6,
    c: px,
    v: 1000,
  }));
}

const saturday = new Date("2026-10-17T16:00:00Z");
assert.equal(usCashSessionOpen(saturday), false);
assert.equal(usCashSessionOpen(new Date("2026-10-19T14:30:00Z")), true);
const weekendBars = flat(40);
weekendBars[weekendBars.length - 1].t = saturday.getTime() - 10 * 60_000;
const flags = indexFlags(weekendBars, saturday.getTime());
assert.ok(flags);
assert.equal(flags.open, false);

assert.equal(parseIso("not-a-date"), null);
assert.equal(parseIso("2026-13-40T00:00:00Z"), null);
const trades = tradesFromCsv(
  "id,logged,status,tkr,label,market,side,entry,stop,target,units,risk,fx,acct,rr,score,nd,exit,closed,r,pnl,notes\n" +
    "abc,yesterday,open,BTC,Bitcoin,Crypto,long,1,0.9,2,1,10,1,AUD,2,4,2,,,,\n" +
    "def,2026-10-19T01:00:00Z,closed,ETH,Ethereum,Crypto,long,1,0.9,2,1,10,1,AUD,2,4,2,1.2,nope,0.4,4,\n" +
    "ghi,2026-10-19T01:00:00Z,closed,SOL,Solana,Crypto,short,1,1.1,0.5,2,10,1,AUD,2,3,2,0.8,2026-10-19T05:00:00Z,1,-4,\n",
);
assert.equal(trades.length, 3);
assert.equal(trades.find((t) => t.id === "abc")?.logged, null);
assert.equal(trades.find((t) => t.id === "def")?.closed, null);
assert.doesNotThrow(() =>
  limitState(
    [...trades, { ...trades[0], status: "closed", closed: "yesterday", pnl: -50, r: -1 }],
    { ...DEFAULTS, f_limits: true, equity: 10000 },
  ),
);

const c = new TtlCache<number>(3);
c.set("a", 1, 1);
c.set("b", 2, 2);
c.set("c", 3, 3);
assert.equal(c.get("a", 100, 10), 1);
c.set("d", 4, 4);
assert.deepEqual(c.keys(), ["c", "a", "d"]);
assert.equal(c.get("a", 5, 20), undefined);

const weekend = new Date("2026-10-17T16:00:00Z");
assert.equal(priceTtlMs("crypto", weekend), 45_000);
assert.equal(priceTtlMs("stock", weekend), 15 * 60_000);
assert.equal(priceTtlMs("stock", new Date("2026-10-19T14:30:00Z")), 180_000);

const d15 = flat(90);
const t0 = d15[d15.length - 1].t;
const push = (o: number, h: number, l: number, cpx: number) => {
  d15.push({ t: t0 + (d15.length - 90) * 15 * 60_000 + 15 * 60_000, o, h, l, c: cpx, v: 5000 });
};
push(100, 100.3, 99.9, 100.2);
push(100.1, 100.3, 99.9, 100.15);
push(100.2, 103.2, 100.1, 102.6);
push(102.4, 103, 101.5, 102.8);
push(102.6, 103.1, 101.6, 102.9);
assert.ok(findZones(d15, 1.2).some((z) => !z.broken && z.type === "demand"));
const dd: Bar[] = Array.from({ length: 40 }, (_, i) => ({
  t: Date.parse("2026-08-01T00:00:00Z") + i * 86_400_000,
  o: 100, h: 103, l: 97, c: 100, v: i === 39 ? 4_000_000 : 2_000_000,
}));
const d1h: Bar[] = Array.from({ length: 40 }, (_, i) => ({
  t: Date.parse("2026-10-01T13:00:00Z") + i * 3_600_000,
  o: 90 + i * 0.2, h: 91 + i * 0.2, l: 89 + i * 0.2, c: 90.5 + i * 0.2, v: 1000,
}));
const plays = buildPlays("TEST", d15, d1h, dd, null, 15, "stock", 1, 1, "America/New_York", d15[d15.length - 1].t + 20 * 60_000);
assert.ok(plays.some((p) => p.side === "long"));

const code = settingsToCode({ ...DEFAULTS, equity: 25000, sel: ["Crypto", "Forex"] });
const back = codeToSettings(code);
assert.equal(back.equity, 25000);
assert.deepEqual(back.sel, ["Crypto", "Forex"]);
assert.throws(() => codeToSettings("nope"));

console.log("zone checks ok", plays.length);
