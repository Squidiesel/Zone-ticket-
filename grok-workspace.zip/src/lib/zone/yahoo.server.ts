import https from "node:https";

import { TtlCache } from "@/lib/zone/cache";
import {
  COUNTRY_CCY,
  FOMC_DECISIONS,
  MAJOR_RE,
  type Bar,
  type EventHit,
  type IndexState,
  type NewsItem,
  type Play,
  type ScreenRow,
  buildPlays,
  indexFlags,
  resampleHour,
  screenRows,
} from "@/lib/zone/engine";
import { type Job, type Kind, isUsMarket } from "@/lib/zone/markets";
import {
  NY,
  SYD,
  parseIso,
  prevBday,
  priceTtlMs,
  zonedLocalToUtc,
  zonedParts,
} from "@/lib/zone/time";

/** One keep-alive pool, four sockets. Stops a scan from opening a connection per ticker. */
const agent = new https.Agent({ keepAlive: true, maxSockets: 4, timeout: 20_000 });

const cache = new TtlCache<{ bars: Bar[]; tz: string }>(400);
const fxCache = new TtlCache<number>(40);
const newsCache = new TtlCache<NewsItem[]>(200);
const earnCache = new TtlCache<Record<string, string[]>>(4);

class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.name = "HttpError";
    this.status = status;
  }
}

class Semaphore {
  private queue: Array<() => void> = [];
  private free: number;
  constructor(max: number) {
    this.free = max;
  }
  async acquire() {
    if (this.free > 0) {
      this.free -= 1;
      return;
    }
    await new Promise<void>((resolve) => this.queue.push(resolve));
  }
  release() {
    const next = this.queue.shift();
    if (next) next();
    else this.free += 1;
  }
}

const gate = new Semaphore(4);
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

type RawRes = { status: number; body: string; location: string };

function httpsRequest(
  url: string,
  method: "GET" | "POST",
  headers: Record<string, string>,
  body?: string,
): Promise<RawRes> {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const req = https.request(
      {
        protocol: u.protocol,
        hostname: u.hostname,
        path: `${u.pathname}${u.search}`,
        method,
        headers: {
          "User-Agent": "Mozilla/5.0",
          Accept: "application/json, text/xml, text/plain, */*",
          "Accept-Encoding": "identity",
          ...headers,
        },
        agent,
        timeout: 12_000,
      },
      (res) => {
        const chunks: Buffer[] = [];
        let size = 0;
        res.on("data", (c: Buffer) => {
          size += c.length;
          if (size > 5_000_000) {
            req.destroy();
            reject(new Error("response too large"));
            return;
          }
          chunks.push(c);
        });
        res.on("end", () => {
          resolve({
            status: res.statusCode ?? 0,
            body: Buffer.concat(chunks).toString("utf8"),
            location: String(res.headers.location ?? ""),
          });
        });
      },
    );
    req.on("timeout", () => {
      req.destroy();
      reject(new HttpError(408, "timeout"));
    });
    req.on("error", reject);
    if (body) req.write(body);
    req.end();
  });
}

async function request(url: string, headers: Record<string, string> = {}, redirects = 0): Promise<string> {
  const res = await httpsRequest(url, "GET", headers);
  if (res.status >= 300 && res.status < 400 && res.location && redirects < 2) {
    return request(new URL(res.location, url).toString(), headers, redirects + 1);
  }
  if (res.status === 429) throw new HttpError(429, "Yahoo rate limit");
  if (res.status >= 400) throw new HttpError(res.status, `HTTP ${res.status}`);
  return res.body;
}

async function withRetry<T>(fn: () => Promise<T>, tries = 3): Promise<T> {
  let last: unknown;
  for (let i = 0; i < tries; i++) {
    try {
      return await fn();
    } catch (e) {
      last = e;
      const status = e instanceof HttpError ? e.status : 0;
      if (status && status < 500 && status !== 429 && status !== 408) throw e;
      const pause = 400 * (i + 1) + Math.random() * 350 + (status === 429 ? 1200 * (i + 1) : 0);
      await sleep(pause);
    }
  }
  throw last instanceof Error ? last : new Error("request failed");
}

/** Four in flight, plus a short random pause so bursts do not trip HTTP 429. */
async function yahooGet(url: string, headers?: Record<string, string>): Promise<string> {
  await gate.acquire();
  try {
    await sleep(120 + Math.random() * 230);
    return await withRetry(() => request(url, headers));
  } finally {
    gate.release();
  }
}

function chartUrl(sym: string, interval: string, range: string): string {
  const u = new URL(`https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(sym)}`);
  u.searchParams.set("interval", interval);
  u.searchParams.set("range", range);
  u.searchParams.set("includePrePost", "false");
  return u.toString();
}

function parseChart(body: string): { bars: Bar[]; tz: string } {
  const json = JSON.parse(body) as {
    chart?: {
      error?: { description?: string } | null;
      result?: Array<{
        meta?: { exchangeTimezoneName?: string };
        timestamp?: number[];
        indicators?: { quote?: Array<{ open?: Array<number | null>; high?: Array<number | null>; low?: Array<number | null>; close?: Array<number | null>; volume?: Array<number | null> }> };
      }> | null;
    };
  };
  const result = json.chart?.result?.[0];
  if (!result) throw new Error(json.chart?.error?.description || "no price data");
  const ts = result.timestamp ?? [];
  const q = result.indicators?.quote?.[0];
  if (!q) throw new Error("no price data");
  const bars: Bar[] = [];
  for (let i = 0; i < ts.length; i++) {
    const o = q.open?.[i];
    const h = q.high?.[i];
    const l = q.low?.[i];
    const c = q.close?.[i];
    if (o == null || h == null || l == null || c == null) continue;
    if (![o, h, l, c].every(Number.isFinite)) continue;
    bars.push({ t: ts[i] * 1000, o, h, l, c, v: q.volume?.[i] ?? 0 });
  }
  if (!bars.length) throw new Error("no price data");
  return { bars, tz: result.meta?.exchangeTimezoneName || "UTC" };
}

async function loadSeries(sym: string, interval: string, range: string, kind: Kind): Promise<{ bars: Bar[]; tz: string; hit: boolean }> {
  const key = `${sym}|${interval}|${range}`;
  const ttl = interval === "1d" && kind !== "crypto" && kind !== "forex" ? Math.max(priceTtlMs(kind), 10 * 60_000) : priceTtlMs(kind);
  const hit = cache.get(key, ttl);
  if (hit) return { ...hit, hit: true };
  const parsed = parseChart(await yahooGet(chartUrl(sym, interval, range)));
  cache.set(key, parsed);
  return { ...parsed, hit: false };
}

function decodeXml(s: string): string {
  return s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/"/g, '"')
    .replace(/&#39;/g, "'")
    .trim();
}

function parseRss(xml: string): NewsItem[] {
  const out: NewsItem[] = [];
  for (const item of xml.split(/<item\b/i).slice(1)) {
    const titleM = item.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    const dateM = item.match(/<pubDate[^>]*>([\s\S]*?)<\/pubDate>/i);
    if (!titleM || !dateM) continue;
    const title = decodeXml(titleM[1]);
    const t = Date.parse(decodeXml(dateM[1]));
    if (!title || Number.isNaN(t)) continue;
    out.push({ t, title });
  }
  return out;
}

async function loadNews(sym: string): Promise<NewsItem[]> {
  const hit = newsCache.get(sym, 10 * 60_000);
  if (hit) return hit;
  const url = `https://feeds.finance.yahoo.com/rss/2.0/headline?s=${encodeURIComponent(sym)}&region=US&lang=en-US`;
  const xml = await yahooGet(url);
  const items = parseRss(xml).slice(0, 12);
  newsCache.set(sym, items);
  return items;
}

async function nasdaqDay(ymdText: string): Promise<string[]> {
  const url = `https://api.nasdaq.com/api/calendar/earnings?date=${ymdText}`;
  const body = await yahooGet(url, {
    Accept: "application/json",
    Origin: "https://www.nasdaq.com",
    Referer: "https://www.nasdaq.com/",
  });
  const json = JSON.parse(body) as { data?: { rows?: Array<{ symbol?: string }> } };
  return (json.data?.rows ?? []).map((r) => String(r.symbol ?? "").toUpperCase()).filter(Boolean);
}

async function earningsBook(now = new Date()): Promise<{ ok: boolean; bySym: Record<string, string[]> }> {
  const today = zonedParts(now, NY).ymd;
  const prev = prevBday(today);
  const key = `${today}|${prev}`;
  const hit = earnCache.get(key, 6 * 60 * 60_000);
  if (hit) return { ok: true, bySym: hit };
  try {
    const [a, b] = await Promise.all([nasdaqDay(today), nasdaqDay(prev)]);
    const bySym: Record<string, string[]> = {};
    const add = (sym: string, d: string) => {
      for (const k of new Set([sym, sym.replace(/\./g, "-"), sym.replace(/-/g, ".")])) {
        bySym[k] = [...(bySym[k] ?? []), d];
      }
    };
    for (const s of a) add(s, today);
    for (const s of b) add(s, prev);
    earnCache.set(key, bySym);
    return { ok: true, bySym };
  } catch {
    return { ok: false, bySym: {} };
  }
}

async function usdPer(ccy: string): Promise<number> {
  if (ccy === "USD") return 1;
  const hit = fxCache.get(ccy, 30 * 60_000);
  if (hit != null) return hit;
  const tryOne = async (sym: string, inv: boolean) => {
    const { bars } = await loadSeries(sym, "1d", "5d", "forex");
    const px = bars[bars.length - 1]?.c;
    if (!px) throw new Error("no rate");
    return inv ? 1 / px : px;
  };
  let v: number;
  try {
    v = await tryOne(`${ccy}USD=X`, false);
  } catch {
    v = await tryOne(`USD${ccy}=X`, true);
  }
  fxCache.set(ccy, v);
  return v;
}

export async function loadRates(ccys: string[]): Promise<Record<string, number>> {
  const out: Record<string, number> = {};
  await mapPool([...new Set(ccys)], 4, async (ccy) => {
    try {
      out[ccy] = await usdPer(ccy);
    } catch {
      /* leave missing; sizing falls back to approximate */
    }
  });
  return out;
}

function parseManual(text: string): EventHit[] {
  const out: EventHit[] = [];
  for (const line of text.split(/\r?\n/)) {
    const m = /^\s*(\d{4}-\d{2}-\d{2})[ T](\d{1,2}):(\d{2})\s*(.*)$/.exec(line);
    if (!m) continue;
    const t = zonedLocalToUtc(SYD, m[1], Number(m[2]), Number(m[3]));
    if (!t) continue;
    out.push({ t: t.getTime(), name: m[4].trim() || "Your blackout", ccy: "ALL" });
  }
  return out;
}

async function fmpEvents(key: string): Promise<EventHit[]> {
  const today = new Date();
  const a = new Date(today.getTime() - 86_400_000).toISOString().slice(0, 10);
  const b = new Date(today.getTime() + 3 * 86_400_000).toISOString().slice(0, 10);
  let problem = "no response";
  for (const base of [
    "https://financialmodelingprep.com/stable/economic-calendar",
    "https://financialmodelingprep.com/api/v3/economic_calendar",
  ]) {
    try {
      const body = await yahooGet(`${base}?from=${a}&to=${b}&apikey=${encodeURIComponent(key)}`);
      const data = JSON.parse(body) as unknown;
      if (!Array.isArray(data)) {
        problem = "the key was refused or the plan does not include the calendar";
        continue;
      }
      const out: EventHit[] = [];
      for (const row of data) {
        if (!row || typeof row !== "object") continue;
        const e = row as Record<string, unknown>;
        const name = String(e.event ?? "");
        const impact = String(e.impact ?? "").toLowerCase();
        if (impact !== "high" && !MAJOR_RE.test(name)) continue;
        const raw = String(e.date ?? "");
        const t = parseIso(raw.includes("T") || raw.endsWith("Z") ? raw : raw.replace(" ", "T"));
        if (!t) continue;
        const ccy = String(e.currency ?? "").toUpperCase() || COUNTRY_CCY[String(e.country ?? "").toUpperCase()] || "";
        if (ccy) out.push({ t: t.getTime(), name, ccy });
      }
      return out;
    } catch (err) {
      problem = err instanceof HttpError ? `HTTP ${err.status}` : "network error";
    }
  }
  throw new Error(problem);
}

export type ContextPayload = {
  events: EventHit[];
  status: string;
  index: IndexState | null;
  rates: Record<string, number>;
  earnOk: boolean;
};

export async function loadContext(manual: string, fmpKey: string): Promise<ContextPayload> {
  const events: EventHit[] = [];
  for (const d of FOMC_DECISIONS) {
    const t = zonedLocalToUtc(NY, d, 14, 0);
    if (t) events.push({ t: t.getTime(), name: "FOMC rate decision", ccy: "USD" });
  }
  events.push(...parseManual(manual.slice(0, 4000)));
  let status = "Event blackouts: built-in FOMC dates";
  if (manual.trim()) status += " and your own times";
  if (fmpKey.trim()) {
    try {
      const more = await fmpEvents(fmpKey.trim().slice(0, 80));
      events.push(...more);
      status += `, plus ${more.length} high-impact releases from FMP`;
    } catch (e) {
      status += `. FMP calendar not loaded (${e instanceof Error ? e.message : "error"})`;
    }
  } else {
    status += ". Add an FMP key in Setup to include CPI, PPI and jobs data";
  }
  const now = Date.now();
  const kept = events.filter((e) => Math.abs(e.t - now) < 2 * 86_400_000);

  const index: IndexState = { open: false, down: [], up: [] };
  let any = false;
  for (const sym of ["SPY", "QQQ"] as const) {
    try {
      const { bars } = await loadSeries(sym, "15m", "5d", "index");
      const f = indexFlags(bars);
      if (!f) continue;
      any = true;
      if (f.open) index.open = true;
      if (f.open && f.down) index.down.push(sym);
      if (f.open && f.up) index.up.push(sym);
    } catch {
      /* one index can fail */
    }
  }

  const rates = await loadRates(["USD", "AUD", "EUR", "GBP", "JPY", "NZD", "CAD", "CHF", "HKD", "CNY"]);
  const earn = await earningsBook();
  return {
    events: kept,
    status,
    index: any ? index : null,
    rates,
    earnOk: earn.ok,
  };
}

export type SymbolResult = {
  sym: string;
  label: string;
  market: string;
  kind: Kind;
  plays: Play[];
  error: string | null;
  cache: "hit" | "miss";
  price: number | null;
  screen: ScreenRow[];
  barTs: number | null;
};

async function scanOne(
  job: Job,
  maxDist: number,
  minScore: number,
  minRr: number,
  perInst: number,
  maxSpread: number,
  earn: Record<string, string[]>,
): Promise<SymbolResult> {
  const base: SymbolResult = {
    sym: job.sym,
    label: job.label,
    market: job.market,
    kind: job.kind,
    plays: [],
    error: null,
    cache: "miss",
    price: null,
    screen: [],
    barTs: null,
  };
  try {
    const d15r = await loadSeries(job.sym, "15m", "1mo", job.kind);
    const ddr = await loadSeries(job.sym, "1d", "6mo", job.kind);
    base.cache = d15r.hit && ddr.hit ? "hit" : "miss";
    const d15 = d15r.bars;
    const dd = ddr.bars;
    const tz = d15r.tz || ddr.tz || "UTC";
    const d1h = resampleHour(d15, tz);
    base.price = d15.length ? d15[d15.length - 1].c : null;
    base.barTs = d15.length ? d15[d15.length - 1].t : null;
    base.screen = d15.length && dd.length
      ? screenRows(job.kind, base.price ?? 0, dd, d15, null, maxSpread, tz)
      : [];
    if (d15.length < 60 || d1h.length < 10 || dd.length < 25) {
      base.error = "not enough data";
      return base;
    }
    let plays = buildPlays(job.sym, d15, d1h, dd, null, maxDist, job.kind, minScore, minRr, tz).slice(0, perInst);
    const us = isUsMarket(job.market);
    let news: NewsItem[] = [];
    let newsOk = true;
    if (us && plays.some((p) => p.score >= 3)) {
      try {
        news = await loadNews(job.sym);
      } catch {
        newsOk = false;
      }
    }
    const earnDates = job.market === "Stocks" ? earn[job.sym] ?? earn[job.sym.replace(/\./g, "-")] ?? [] : [];
    plays = plays.map((p) => ({
      ...p,
      label: job.label,
      market: job.market,
      us,
      news: us ? news : [],
      newsOk,
      earn: earnDates,
    }));
    base.plays = plays;
    return base;
  } catch (e) {
    base.error = e instanceof Error ? e.message.slice(0, 80) : "failed";
    return base;
  }
}

export async function scanBatch(
  jobs: Job[],
  opts: { maxDist: number; minScore: number; minRr: number; perInst: number; maxSpread: number },
): Promise<{ results: SymbolResult[]; earnOk: boolean }> {
  const earn = await earningsBook();
  const results = await mapPool(jobs.slice(0, 4), 4, (job) =>
    scanOne(
      job,
      opts.maxDist,
      opts.minScore,
      opts.minRr,
      Math.max(1, Math.min(6, Math.trunc(opts.perInst))),
      opts.maxSpread,
      earn.bySym,
    ),
  );
  return { results, earnOk: earn.ok };
}

export async function mapPool<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let i = 0;
  const n = Math.max(1, Math.min(limit, items.length));
  async function worker() {
    for (;;) {
      const idx = i;
      i += 1;
      if (idx >= items.length) return;
      out[idx] = await fn(items[idx]);
    }
  }
  if (!items.length) return [];
  await Promise.all(Array.from({ length: n }, () => worker()));
  return out;
}

export async function sendNtfy(topic: string, title: string, body: string, priority = "default"): Promise<void> {
  const clean = topic.trim();
  if (!/^[A-Za-z0-9_-]{6,64}$/.test(clean)) {
    throw new Error("Topic must be 6 to 64 letters, numbers, dashes or underscores.");
  }
  const safeTitle = title.replace(/[^\x20-\x7e]/g, "").slice(0, 120);
  const res = await httpsRequest(`https://ntfy.sh/${clean}`, "POST", {
    Title: safeTitle,
    Priority: priority,
    Tags: "chart_with_upwards_trend",
    "Content-Type": "text/plain; charset=utf-8",
  }, body.slice(0, 3500));
  if (res.status !== 200) throw new Error(`ntfy answered HTTP ${res.status}`);
}
