import {
  CHECK_WHY,
  INDEX_CCY,
  type Kind,
  type Settings,
  levOf,
} from "@/lib/zone/markets";
import {
  NY,
  SYD,
  fmtAge,
  fmtZone,
  minutesOfDay,
  parseIso,
  prevBday,
  usCashSessionOpen,
  ymd,
  zonedParts,
} from "@/lib/zone/time";

export { CHECK_WHY };

export const RV_STRONG = 2;
export const SCREEN_RVOL = 1.2;
export const IDX_BARS = 4;
export const IDX_NET = 3;
export const IDX_BAR = 2;
export const ATR_RANGE: Record<Kind, [number, number]> = {
  stock: [1.5, 10],
  forex: [0.25, 2.5],
  commodity: [0.8, 5],
  index: [0.6, 6],
  crypto: [2, 10],
};

export type Bar = { t: number; o: number; h: number; l: number; c: number; v: number };
export type Side = "long" | "short";
export type ReactState = "rejected" | "touched" | "waiting";
export type Htf = "up" | "down" | "range";

export type NewsItem = { t: number; title: string };
export type Check = { label: string; state: boolean | null; detail: string };

export type Play = {
  tkr: string;
  side: Side;
  kind: Kind;
  nd: number;
  barTs: number | null;
  px: number;
  adv: number;
  rvol: number;
  atr: number;
  spr: number | null;
  prox: number;
  dist: number;
  tgt: number;
  rr: number;
  score: number;
  sc: boolean[];
  screen: boolean[];
  take: boolean;
  tf: "15m";
  atr15: number;
  vwap: number | null;
  rv: number | null;
  rvBasis: "touch" | "approach" | null;
  htf: Htf;
  depart: number;
  ageBars: number;
  nested: boolean;
  react: ReactState;
  label: string;
  market: string;
  us: boolean;
  news: NewsItem[];
  newsOk: boolean;
  earn: string[];
  checks?: Check[];
};

export type Size = {
  stop: number;
  units: number;
  notional: number;
  margin: number;
  approx: boolean;
  ccy: string;
  acct: string;
  cur: string;
  fx: number;
  marginPct: number;
  lev: number;
  loss: number;
  gain: number;
};

export type ScreenRow = { label: string; value: string; ok: boolean | null };

export type Zone = {
  type: "demand" | "supply";
  prox: number;
  dist: number;
  height: number;
  idx: number;
  depart: number;
  volx: number;
  fresh: boolean;
  broken: boolean;
};

const NEG_RE =
  /\b(halt(ed|s)?|investigat\w+|probe[ds]?|subpoena\w*|lawsuit|sues?|sued|fraud\w*|bankrupt\w*|chapter 11|delist\w*|recall\w*|downgrad\w+|plunge\w*|tumbl\w+|crash\w*|slump\w*|miss(es|ed)?|(cuts?|lowers?|slashes?) (guidance|forecast|outlook)|warning|resigns?|steps? down|(public |stock |share )?offering|dilut\w+|short[- ]seller|SEC charges|data breach|cyberattack|complete response letter|rejects?|tariffs?)\b/i;
const POS_RE =
  /\b(upgrad\w+|surg\w+|soar\w*|jump\w*|rall(y|ies|ied)|beats?|raises? (guidance|forecast|outlook)|record (high|revenue|earnings)|approv\w+|acquir\w+|acquisition|buyout|takeover|partnership|wins?|breakthrough)\b/i;
export const MAJOR_RE =
  /(\bcpi\b|consumer price|\bppi\b|producer price|non-?farm|payrolls|fomc|fed funds|interest rate (decision|announcement)|rate decision|\bgdp\b|retail sales|\bpce\b|unemployment rate|jobless claims)/i;

export const FOMC_DECISIONS = [
  "2026-01-28", "2026-03-18", "2026-04-29", "2026-06-17",
  "2026-07-29", "2026-09-16", "2026-10-28", "2026-12-09",
];

export const COUNTRY_CCY: Record<string, string> = {
  US: "USD", EU: "EUR", EMU: "EUR", DE: "EUR", FR: "EUR", IT: "EUR", ES: "EUR",
  GB: "GBP", UK: "GBP", JP: "JPY", AU: "AUD", NZ: "NZD", CA: "CAD",
  CH: "CHF", CN: "CNY", HK: "HKD",
};

function mean(xs: number[]): number {
  if (!xs.length) return 0;
  let s = 0;
  for (const x of xs) s += x;
  return s / xs.length;
}

export function roundTo(n: number, nd: number): number {
  const f = 10 ** nd;
  return Math.round(n * f) / f;
}

export function fmt(v: number, nd: number): string {
  return v.toLocaleString("en-US", { minimumFractionDigits: nd, maximumFractionDigits: nd });
}

export function money(cur: string, v: number): string {
  return `${v < 0 ? "-" : ""}${cur}${Math.abs(v).toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
}

export function decimals(price: number, sym = ""): number {
  if (sym.endsWith("=X") && sym.includes("JPY")) return 3;
  if (price >= 100) return 2;
  if (price >= 10) return 3;
  if (price >= 1) return 5;
  return 6;
}

export function atrSeries(bars: Bar[], n = 14): number[] {
  const out = new Array<number>(bars.length).fill(Number.NaN);
  const tr: number[] = [];
  for (let i = 0; i < bars.length; i++) {
    const b = bars[i];
    const pc = i ? bars[i - 1].c : b.c;
    tr.push(Math.max(b.h - b.l, Math.abs(b.h - pc), Math.abs(b.l - pc)));
  }
  let sum = 0;
  for (let i = 0; i < tr.length; i++) {
    sum += tr[i];
    if (i >= n) sum -= tr[i - n];
    if (i >= n - 1) out[i] = sum / n;
  }
  return out;
}

export function atrLast(bars: Bar[], n = 14): number {
  const s = atrSeries(bars, n);
  return s.length ? s[s.length - 1] : Number.NaN;
}

export function completed(bars: Bar[], minutes = 15, now = Date.now()): Bar[] {
  if (bars.length <= 1) return bars;
  const last = bars[bars.length - 1];
  if (now - last.t < minutes * 60_000) return bars.slice(0, -1);
  return bars;
}

export function sessionVwap(bars: Bar[], tz: string): number | null {
  if (!bars.length || bars.reduce((s, b) => s + b.v, 0) <= 0) return null;
  const day = ymd(bars[bars.length - 1].t, tz);
  const last = bars.filter((b) => ymd(b.t, tz) === day);
  const vsum = last.reduce((s, b) => s + b.v, 0);
  if (vsum <= 0) return null;
  let acc = 0;
  for (const b of last) acc += ((b.h + b.l + b.c) / 3) * b.v;
  return acc / vsum;
}

export function intradayRvol(bars: Bar[], tz: string): { map: Map<number, number>; cum: number | null } {
  const empty = { map: new Map<number, number>(), cum: null };
  if (bars.length < 30 || bars.reduce((s, b) => s + b.v, 0) <= 0) return empty;
  const byDay = new Map<string, Map<number, number>>();
  for (const b of bars) {
    const day = ymd(b.t, tz);
    const slot = minutesOfDay(b.t, tz);
    let m = byDay.get(day);
    if (!m) {
      m = new Map();
      byDay.set(day, m);
    }
    m.set(slot, (m.get(slot) ?? 0) + b.v);
  }
  if (byDay.size < 4) return empty;
  const today = [...byDay.keys()].at(-1)!;
  const map = new Map<number, number>();
  for (const b of bars.slice(-8)) {
    const day = ymd(b.t, tz);
    const slot = minutesOfDay(b.t, tz);
    const others: number[] = [];
    let cur: number | undefined;
    for (const [d, slots] of byDay) {
      const v = slots.get(slot);
      if (v == null) continue;
      if (d === day) cur = v;
      else others.push(v);
    }
    if (cur == null || others.length < 3) continue;
    const avg = mean(others);
    if (avg <= 0) continue;
    map.set(b.t, cur / avg);
  }
  const lastSlot = minutesOfDay(bars[bars.length - 1].t, tz);
  const othersCum: number[] = [];
  let todayCum: number | null = null;
  for (const [d, slots] of byDay) {
    let s = 0;
    let any = false;
    for (const [slot, v] of slots) {
      if (slot <= lastSlot) {
        s += v;
        any = true;
      }
    }
    if (!any) continue;
    if (d === today) todayCum = s;
    else othersCum.push(s);
  }
  let cum: number | null = null;
  if (todayCum != null && othersCum.length >= 3) {
    const avg = mean(othersCum);
    if (avg > 0) cum = todayCum / avg;
  }
  return { map, cum };
}

export function structure(bars: Bar[], n = 2): Htf {
  const hi = bars.map((b) => b.h);
  const lo = bars.map((b) => b.l);
  const ph: number[] = [];
  const pl: number[] = [];
  for (let i = n; i < bars.length - n; i++) {
    let maxH = -Infinity;
    let minL = Infinity;
    for (let k = i - n; k <= i + n; k++) {
      maxH = Math.max(maxH, hi[k]);
      minL = Math.min(minL, lo[k]);
    }
    if (hi[i] === maxH) ph.push(hi[i]);
    if (lo[i] === minL) pl.push(lo[i]);
  }
  if (ph.length >= 2 && pl.length >= 2) {
    const ph1 = ph[ph.length - 1];
    const ph2 = ph[ph.length - 2];
    const pl1 = pl[pl.length - 1];
    const pl2 = pl[pl.length - 2];
    if (ph1 < ph2 && pl1 < pl2) return "down";
    if (ph1 > ph2 && pl1 > pl2) return "up";
  }
  return "range";
}

export function ema(values: number[], span: number): number[] {
  if (!values.length) return [];
  const k = 2 / (span + 1);
  const out = [values[0]];
  let prev = values[0];
  for (let i = 1; i < values.length; i++) {
    prev = values[i] * k + prev * (1 - k);
    out.push(prev);
  }
  return out;
}

/**
 * Index impulse flags. `open` is true only when the New York cash session is
 * actually in progress AND the last 15m bar is fresh. A weekend or a shifted
 * timestamp cannot mark the market open by itself.
 */
export function indexFlags(
  bars: Bar[],
  nowMs = Date.now(),
): { open: boolean; down: boolean; up: boolean } | null {
  const a = atrLast(bars);
  const dc = completed(bars, 15, nowMs);
  if (!a || !Number.isFinite(a) || dc.length <= IDX_BARS) return null;
  const last = dc[dc.length - 1];
  const prev = dc[dc.length - 1 - IDX_BARS];
  const net = (last.c - prev.c) / a;
  const bar = (last.c - last.o) / a;
  const sessionOpen = usCashSessionOpen(new Date(nowMs));
  const fresh = bars.length > 0 && nowMs - bars[bars.length - 1].t < 40 * 60_000;
  return {
    open: sessionOpen && fresh,
    down: net <= -IDX_NET || bar <= -IDX_BAR,
    up: net >= IDX_NET || bar >= IDX_BAR,
  };
}

export function findZones(bars: Bar[], a: number, impulse = 2): Zone[] {
  const n = bars.length;
  if (!a || !Number.isFinite(a) || n < 5) return [];
  const o = bars.map((b) => b.o);
  const h = bars.map((b) => b.h);
  const l = bars.map((b) => b.l);
  const c = bars.map((b) => b.c);
  const v = bars.map((b) => b.v);
  const body = c.map((x, i) => Math.abs(x - o[i]));
  const rng = h.map((x, i) => x - l[i]);
  const small = body.map((x, i) => x <= 0.5 * a && rng[i] <= 1.2 * a);
  const avgv = mean(v);
  const zones: Zone[] = [];
  for (let j = 1; j < n - 1; j++) {
    let k = 0;
    while (k < 3 && j - 1 - k >= 0 && small[j - 1 - k]) k += 1;
    if (k === 0 || body[j] < 0.8 * a) continue;
    const end = Math.min(j + 3, n);
    let typ: "demand" | "supply";
    let prox: number;
    let dist: number;
    let move: number;
    if (c[j] > o[j]) {
      let low = Infinity;
      let baseO = -Infinity;
      let baseC = -Infinity;
      for (let i = j - k; i < j; i++) {
        low = Math.min(low, l[i]);
        baseO = Math.max(baseO, o[i]);
        baseC = Math.max(baseC, c[i]);
      }
      let hi = -Infinity;
      for (let i = j; i < end; i++) hi = Math.max(hi, h[i]);
      move = hi - low;
      if (move < impulse * a) continue;
      typ = "demand";
      prox = Math.max(baseO, baseC);
      dist = low;
    } else if (c[j] < o[j]) {
      let high = -Infinity;
      let baseO = Infinity;
      let baseC = Infinity;
      for (let i = j - k; i < j; i++) {
        high = Math.max(high, h[i]);
        baseO = Math.min(baseO, o[i]);
        baseC = Math.min(baseC, c[i]);
      }
      let lo = Infinity;
      for (let i = j; i < end; i++) lo = Math.min(lo, l[i]);
      move = high - lo;
      if (move < impulse * a) continue;
      typ = "supply";
      prox = Math.min(baseO, baseC);
      dist = high;
    } else {
      continue;
    }
    const height = Math.abs(prox - dist);
    if (height < 0.05 * a) continue;
    const afterStart = Math.min(j + 3, n);
    let broken = false;
    const hits: number[] = [];
    for (let i = afterStart; i < n; i++) {
      if (typ === "demand") {
        if (c[i] < dist) broken = true;
        if (l[i] <= prox) hits.push(i);
      } else {
        if (c[i] > dist) broken = true;
        if (h[i] >= prox) hits.push(i);
      }
    }
    const first = hits.length ? hits[0] : null;
    const touched = first != null && first < n - 5;
    zones.push({
      type: typ,
      prox,
      dist,
      height,
      idx: j,
      depart: move / a,
      volx: avgv ? v[j] / avgv : 0,
      fresh: !touched,
      broken,
    });
  }
  return zones;
}

export function reaction(
  d15c: Bar[],
  prox: number,
  long: boolean,
  look = 4,
): [ReactState, number | null] {
  const t = d15c.slice(-(look + 1));
  if (t.length < 2) return ["waiting", null];
  for (let i = t.length - 1; i > 0; i--) {
    const hit = long ? t[i].l <= prox : t[i].h >= prox;
    if (!hit) continue;
    const rng = t[i].h - t[i].l;
    if (rng <= 0) return ["touched", t[i].t];
    if (long) {
      const out = t[i].c > prox;
      const wick = Math.min(t[i].o, t[i].c) - t[i].l >= 0.5 * rng;
      const engulf =
        t[i].c > t[i].o &&
        t[i].c >= t[i - 1].o &&
        t[i].o <= t[i - 1].c &&
        t[i - 1].c < t[i - 1].o;
      return [out && (wick || engulf) ? "rejected" : "touched", t[i].t];
    }
    const out = t[i].c < prox;
    const wick = t[i].h - Math.max(t[i].o, t[i].c) >= 0.5 * rng;
    const engulf =
      t[i].c < t[i].o &&
      t[i].c <= t[i - 1].o &&
      t[i].o >= t[i - 1].c &&
      t[i - 1].c > t[i - 1].o;
    return [out && (wick || engulf) ? "rejected" : "touched", t[i].t];
  }
  return ["waiting", null];
}

export function resampleHour(bars: Bar[], tz: string): Bar[] {
  const out: Bar[] = [];
  let cur: Bar | null = null;
  let key = "";
  for (const b of bars) {
    const k = `${ymd(b.t, tz)}T${Math.floor(minutesOfDay(b.t, tz) / 60)}`;
    if (!cur || k !== key) {
      if (cur) out.push(cur);
      cur = { ...b };
      key = k;
    } else {
      cur.h = Math.max(cur.h, b.h);
      cur.l = Math.min(cur.l, b.l);
      cur.c = b.c;
      cur.v += b.v;
    }
  }
  if (cur) out.push(cur);
  return out;
}

export function buildPlays(
  tk: string,
  d15: Bar[],
  d1h: Bar[],
  dd: Bar[],
  spread: number | null,
  maxDist: number,
  kind: Kind,
  minScore: number,
  minRr: number,
  tz: string,
  now = Date.now(),
): Play[] {
  const a = atrLast(d15);
  if (!a || !Number.isFinite(a) || !d15.length || dd.length < 5) return [];
  const price = d15[d15.length - 1].c;
  const nd = decimals(price, tk);
  const barTs = d15[d15.length - 1].t;
  const advSlice = dd.slice(Math.max(0, dd.length - 21), dd.length - 1);
  const adv = mean(advSlice.map((b) => b.v));
  const rvolDaily = adv ? dd[dd.length - 1].v / adv : 0;
  const atrD = atrLast(dd);
  const atrPct = dd[dd.length - 1].c ? (atrD / dd[dd.length - 1].c) * 100 : Number.NaN;

  const d15c = completed(d15, 15, now);
  const { map: barMap, cum } = intradayRvol(d15c, tz);
  const rvol = cum != null ? cum : rvolDaily;
  const vwap = sessionVwap(d15, tz);
  const htf = structure(d1h.slice(-80));

  const ema1h = ema(d1h.map((b) => b.c), 20);
  const up1h =
    ema1h.length > 5 &&
    d1h[d1h.length - 1].c > ema1h[ema1h.length - 1] &&
    ema1h[ema1h.length - 1] > ema1h[ema1h.length - 5];
  const dn1h =
    ema1h.length > 5 &&
    d1h[d1h.length - 1].c < ema1h[ema1h.length - 1] &&
    ema1h[ema1h.length - 1] < ema1h[ema1h.length - 5];
  const emad = ema(dd.map((b) => b.c), 20);
  const upd = emad.length > 0 && dd[dd.length - 1].c > emad[emad.length - 1];
  const dnd = emad.length > 0 && dd[dd.length - 1].c < emad[emad.length - 1];

  const [lo, hi] = ATR_RANGE[kind] ?? ATR_RANGE.stock;
  const screen =
    kind === "stock"
      ? [price > 5, adv >= 1e6, rvol >= SCREEN_RVOL, lo <= atrPct && atrPct <= hi]
      : [lo <= atrPct && atrPct <= hi];
  const screenOk = screen.every(Boolean);

  const zones = findZones(d15, a).filter((z) => !z.broken);
  const session = d15.slice(-52);
  const plays: Play[] = [];
  for (const z of zones) {
    const long = z.type === "demand";
    const entry = z.prox;
    if (long && !(price > entry)) continue;
    if (!long && !(price < entry)) continue;
    if (Math.abs(price - entry) > maxDist * a) continue;
    const opp = zones.filter((x) => x.type === (long ? "supply" : "demand"));
    let tgt: number;
    if (long) {
      const ahead = opp.map((x) => x.prox).filter((x) => x > price);
      tgt = ahead.length ? Math.min(...ahead) : Math.max(...session.map((b) => b.h));
      if (tgt <= entry) continue;
    } else {
      const ahead = opp.map((x) => x.prox).filter((x) => x < price);
      tgt = ahead.length ? Math.max(...ahead) : Math.min(...session.map((b) => b.l));
      if (tgt >= entry) continue;
    }
    const buf = z.height * 0.1;
    const stop = long ? z.dist - buf : z.dist + buf;
    const risk = Math.abs(entry - stop);
    if (risk <= 0) continue;
    const rr = Math.abs(tgt - entry) / risk;
    const ageBars = d15.length - 1 - z.idx;
    const nested = opp.some(
      (x) => x.height > z.height && Math.min(x.prox, x.dist) <= entry && entry <= Math.max(x.prox, x.dist),
    );
    const [react] = reaction(d15c, entry, long, 4);
    let rv: number | null = null;
    let basis: "touch" | "approach" | null = null;
    if (barMap.size && d15c.length) {
      for (let k = 1; k <= 4 && k <= d15c.length; k++) {
        const r = d15c[d15c.length - k];
        if ((long && r.l <= entry) || (!long && r.h >= entry)) {
          const got = barMap.get(r.t);
          if (got != null) {
            rv = got;
            basis = "touch";
          }
          break;
        }
      }
      if (rv == null) {
        const vals = d15c.slice(-2).map((b) => barMap.get(b.t)).filter((x): x is number => x != null);
        if (vals.length) {
          rv = mean(vals);
          basis = "approach";
        }
      }
    }
    const checks = [
      z.depart >= 3,
      z.fresh,
      z.height <= 1 * a,
      long ? up1h && upd : dn1h && dnd,
      kind === "stock" ? z.volx >= 1.5 || rvol >= 2 || (rv != null && rv >= RV_STRONG) : z.depart >= 4,
    ];
    const score = checks.reduce((s, x) => s + (x ? 1 : 0), 0);
    const take = screenOk && score >= minScore && rr >= minRr;
    plays.push({
      tkr: tk,
      side: long ? "long" : "short",
      kind,
      nd,
      barTs,
      px: roundTo(price, nd),
      adv: Math.round(adv),
      rvol: roundTo(rvol, 2),
      atr: roundTo(atrPct, 2),
      spr: spread == null ? null : roundTo(spread, 3),
      prox: roundTo(entry, nd),
      dist: roundTo(z.dist, nd),
      tgt: roundTo(tgt, nd),
      rr: roundTo(rr, 1),
      score,
      sc: checks,
      screen,
      take,
      tf: "15m",
      atr15: a,
      vwap: vwap == null ? null : roundTo(vwap, nd),
      rv: rv == null ? null : roundTo(rv, 2),
      rvBasis: basis,
      htf,
      depart: roundTo(z.depart, 1),
      ageBars,
      nested,
      react,
      label: tk,
      market: "",
      us: false,
      news: [],
      newsOk: true,
      earn: [],
    });
  }
  plays.sort((a, b) => {
    if (a.take !== b.take) return a.take ? -1 : 1;
    return b.score - a.score || b.rr - a.rr;
  });
  return plays;
}

export function screenRows(
  kind: Kind,
  price: number,
  dd: Bar[],
  d15: Bar[],
  spread: number | null,
  maxSpread: number,
  tz: string,
  now = Date.now(),
): ScreenRow[] {
  const atrPct = dd.length ? (atrLast(dd) / dd[dd.length - 1].c) * 100 : Number.NaN;
  const [lo, hi] = ATR_RANGE[kind] ?? ATR_RANGE.stock;
  if (kind !== "stock") {
    return [{
      label: `Daily range ${lo}-${hi}%`,
      value: Number.isFinite(atrPct) ? `${atrPct.toFixed(2)}%` : "n/a",
      ok: Number.isFinite(atrPct) ? lo <= atrPct && atrPct <= hi : false,
    }];
  }
  const advSlice = dd.slice(Math.max(0, dd.length - 21), Math.max(0, dd.length - 1));
  const adv = mean(advSlice.map((b) => b.v));
  const rvd = adv && dd.length ? dd[dd.length - 1].v / adv : 0;
  const { cum } = intradayRvol(completed(d15, 15, now), tz);
  const rv = cum != null ? cum : rvd;
  return [
    { label: "Price above $5", value: `$${price.toLocaleString("en-US", { maximumFractionDigits: 2 })}`, ok: price > 5 },
    { label: "Avg volume 1M+", value: adv.toLocaleString("en-US", { maximumFractionDigits: 0 }), ok: adv >= 1e6 },
    {
      label: cum != null ? `Relative volume ${SCREEN_RVOL}x+ (same time of day)` : `Relative volume ${SCREEN_RVOL}x+ (daily)`,
      value: `${rv.toFixed(1)}x`,
      ok: rv >= SCREEN_RVOL,
    },
    {
      label: `Daily range ${lo}-${hi}%`,
      value: Number.isFinite(atrPct) ? `${atrPct.toFixed(1)}%` : "n/a",
      ok: Number.isFinite(atrPct) ? lo <= atrPct && atrPct <= hi : false,
    },
    {
      label: `Spread ${maxSpread.toFixed(3)}% or less`,
      value: spread == null ? "n/a" : `${spread.toFixed(3)}%`,
      ok: spread == null ? null : spread <= maxSpread,
    },
  ];
}

export function quoteCcy(p: Pick<Play, "tkr" | "kind">): string {
  if (p.kind === "forex" && p.tkr.length >= 6) return p.tkr.slice(3, 6);
  return INDEX_CCY[p.tkr] ?? "USD";
}

export function sizeOf(
  p: Play,
  equity: number,
  riskPct: number,
  levCap: number,
  acct: string,
  fx: number | null,
): Size {
  const long = p.side === "long";
  const height = Math.abs(p.prox - p.dist);
  const stop = long ? p.dist - height * 0.1 : p.dist + height * 0.1;
  const ccy = quoteCcy(p);
  const approx = fx == null;
  const f = fx ?? 1;
  const perUnit = Math.abs(p.prox - stop) * f;
  const units = perUnit > 0 ? Math.floor((equity * riskPct) / 100 / perUnit) : 0;
  const notional = units * p.prox * f;
  const margin = levCap > 0 ? notional / levCap : Number.POSITIVE_INFINITY;
  return {
    stop,
    units,
    notional,
    margin,
    approx,
    ccy,
    acct,
    cur: acct === "AUD" ? "A$" : "$",
    fx: f,
    marginPct: equity > 0 ? (margin / equity) * 100 : 0,
    lev: equity > 0 ? notional / equity : 0,
    loss: units * perUnit,
    gain: units * Math.abs(p.tgt - p.prox) * f,
  };
}

export function numberChecks(p: Play, s: Size, levCap: number, S: Settings): Check[] {
  const ms = S.min_score;
  const mr = S.min_rr_take;
  const names = p.kind === "stock"
    ? ["price above $5", "average volume 1M+", `relative volume ${SCREEN_RVOL}x+`, "daily range"]
    : ["daily range"];
  const failed = names.filter((_, i) => !p.screen[i]);
  const out: Check[] = [];
  out.push({
    label: "Passes the screen",
    state: failed.length === 0,
    detail: failed.length ? `fails the screen: ${failed.join(", ")}` : "enough volume and movement to be worth trading",
  });
  out.push({
    label: "Zone score",
    state: p.score >= ms,
    detail: p.score >= ms ? `${p.score}/5, needs ${ms.toFixed(0)}` : `zone score ${p.score}/5, needs ${ms.toFixed(0)}`,
  });
  out.push({
    label: "Reward : risk",
    state: p.rr >= mr,
    detail: p.rr >= mr ? `${p.rr.toFixed(1)} to 1, needs ${mr}` : `reward to risk ${p.rr.toFixed(1)}, needs ${mr}`,
  });
  out.push({
    label: "Affordable size",
    state: s.units >= 1,
    detail: s.units >= 1 ? `${s.units.toLocaleString("en-US")} units` : "risk amount too small for one unit",
  });
  out.push({
    label: "Leverage within limit",
    state: s.lev <= levCap,
    detail: s.lev <= levCap
      ? `${s.lev.toFixed(1)}x of ${levCap.toFixed(0)}x allowed`
      : `needs ${s.lev.toFixed(1)}x leverage, limit ${levCap.toFixed(0)}x`,
  });
  out.push({
    label: "Margin under 50%",
    state: s.marginPct <= 50,
    detail: s.marginPct <= 50
      ? `${s.marginPct.toFixed(0)}% of equity`
      : `margin is ${s.marginPct.toFixed(0)}% of equity, keep under 50%`,
  });
  return out;
}

export function zonePoints(p: Play): [string, boolean][] {
  const last = p.kind === "stock" ? "Volume or interest at the zone" : "Strong momentum (4+ ATR departure)";
  const labels = ["Strong departure (3+ ATR)", "Untouched since forming", "Tight base", "Higher timeframes agree", last];
  return labels.map((lab, i) => [lab, Boolean(p.sc[i])]);
}

export type EventHit = { t: number; name: string; ccy: string };
export type IndexState = { open: boolean; down: string[]; up: string[] };
export type Ctx = { events: EventHit[]; status: string; index: IndexState | null };

function ccyApplies(ccy: string, p: Play): boolean {
  if (ccy === "ALL" || ccy === "USD") return true;
  if (p.kind === "forex" && p.tkr.length >= 6) return ccy === p.tkr.slice(0, 3) || ccy === p.tkr.slice(3, 6);
  return INDEX_CCY[p.tkr] === ccy;
}

export function filterChecks(p: Play, S: Settings, ctx: Ctx, nowMs = Date.now()): Check[] {
  const out: Check[] = [];
  const long = p.side === "long";
  const add = (label: string, state: boolean | null, detail: string) => out.push({ label, state, detail });
  const now = new Date(nowMs);

  if (!S.f_stale) add("Fresh data", null, "filter off");
  else if (p.barTs == null) add("Fresh data", null, "no candle time");
  else {
    const age = (nowMs - p.barTs) / 60_000;
    if (age > S.stale_min) {
      add("Fresh data", false, `stale data: last candle ${fmtAge(age)} old (${fmtZone(p.barTs, SYD)} Sydney), market probably closed`);
    } else add("Fresh data", true, `last candle ${fmtAge(age)} old`);
  }

  if (!S.f_events) add("No news event nearby", null, "filter off");
  else {
    let hit: { e: EventHit; mins: number } | null = null;
    for (const e of ctx.events) {
      if (!ccyApplies(e.ccy, p)) continue;
      const mins = (e.t - nowMs) / 60_000;
      if (-S.ev_min <= mins && mins <= S.ev_min) {
        hit = { e, mins };
        break;
      }
    }
    if (hit) {
      add("No news event nearby", false, `news blackout: ${hit.e.name} ${fmtZone(hit.e.t, SYD, { weekday: false })} Sydney (${hit.mins >= 0 ? "+" : ""}${hit.mins.toFixed(0)} min)`);
    } else add("No news event nearby", true, `no major event within ${S.ev_min.toFixed(0)} minutes`);
  }

  if (p.us) {
    if (p.spr == null) add("Spread", null, "spread unknown");
    else if (p.spr > S.max_spread) add("Spread", false, `spread ${p.spr.toFixed(3)}% is over your ${S.max_spread.toFixed(3)}% limit`);
    else add("Spread", true, `${p.spr.toFixed(3)}%, limit ${S.max_spread.toFixed(3)}%`);

    if (!S.f_earn) add("No earnings risk", null, "filter off");
    else if (p.market !== "Stocks") add("No earnings risk", null, "not a single stock");
    else {
      const today = zonedParts(now, NY).ymd;
      const prev = prevBday(today);
      let msg: string | null = null;
      for (const d of p.earn) {
        if (d === today) {
          msg = `earnings today (${d})`;
          break;
        }
        if (d === prev) {
          msg = `earnings ${d}, gap risk the day after`;
          break;
        }
      }
      add("No earnings risk", msg == null, msg ?? "no earnings today or yesterday");
    }

    if (!S.f_news) add("No bad headline", null, "filter off");
    else if (p.newsOk === false) add("No bad headline", null, "headlines could not be read");
    else {
      const bad = long ? NEG_RE : POS_RE;
      let msg: string | null = null;
      const news = [...p.news].sort((a, b) => b.t - a.t);
      for (const item of news) {
        const age = (nowMs - item.t) / 3_600_000;
        if (age >= 0 && age <= S.news_hrs && bad.test(item.title)) {
          msg = `${long ? "negative" : "positive"} headline ${age.toFixed(1)}h ago: "${item.title.slice(0, 70)}"`;
          break;
        }
      }
      add("No bad headline", msg == null, msg ?? `nothing against the trade in the last ${S.news_hrs}h`);
    }

    if (!S.f_rvol) add("Volume at the zone", null, "filter off");
    else if (p.rv == null) add("Volume at the zone", null, "no volume reading");
    else if (p.rv < S.rv_weak) add("Volume at the zone", false, `weak volume at the zone (${p.rv.toFixed(1)}x normal for this time)`);
    else add("Volume at the zone", true, `${p.rv.toFixed(1)}x normal for this time of day`);

    const idx = ctx.index;
    if (!S.f_index) add("Index calm", null, "filter off");
    else if (!idx || !idx.open) add("Index calm", null, "US market closed or index unreadable");
    else if (long && idx.down.length) add("Index calm", false, `${idx.down.join("/")} selling off, wait for it to settle`);
    else if (!long && idx.up.length) add("Index calm", false, `${idx.up.join("/")} spiking, wait for it to settle`);
    else add("Index calm", true, "SPY and QQQ are not making a sharp move");
  }

  if (!S.f_vwap) add("VWAP side", null, "filter off");
  else if (p.vwap == null || !p.atr15) add("VWAP side", null, "no volume feed, so no VWAP");
  else {
    const gap = (p.prox - p.vwap) / p.atr15;
    if (long && gap < -S.vwap_tol) add("VWAP side", false, `demand zone is ${Math.abs(gap).toFixed(1)} ATR below session VWAP`);
    else if (!long && gap > S.vwap_tol) add("VWAP side", false, `supply zone is ${gap.toFixed(1)} ATR above session VWAP`);
    else add("VWAP side", true, `zone is ${gap >= 0 ? "+" : ""}${gap.toFixed(1)} ATR from VWAP, limit ${S.vwap_tol}`);
  }

  if (!S.f_htf) add("1h trend agrees", null, "filter off");
  else {
    const against = p.htf === (long ? "down" : "up");
    add(
      "1h trend agrees",
      !against,
      against
        ? `counter-trend: 1h makes ${long ? "lower highs and lower lows" : "higher highs and higher lows"}`
        : `1h structure is ${p.htf}, not against the trade`,
    );
  }

  if (!S.f_depart) add("Strong departure", null, "filter off");
  else if (p.depart < S.zq_depart) {
    add("Strong departure", false, `weak departure: the zone only moved ${p.depart.toFixed(1)} ATR away (needs ${S.zq_depart.toFixed(1)})`);
  } else add("Strong departure", true, `moved ${p.depart.toFixed(1)} ATR away, needs ${S.zq_depart.toFixed(1)}`);

  if (!S.f_age) add("Young zone", null, "filter off");
  else if (p.ageBars > S.zq_age * 4) {
    add("Young zone", false, `old zone: formed about ${(p.ageBars / 4).toFixed(0)}h of trading ago (limit ${S.zq_age.toFixed(0)}h)`);
  } else add("Young zone", true, `about ${(p.ageBars / 4).toFixed(0)}h old, limit ${S.zq_age.toFixed(0)}h`);

  if (!S.f_nest) add("Not nested", null, "filter off");
  else if (p.nested) add("Not nested", false, `the zone sits inside a bigger ${long ? "supply" : "demand"} zone`);
  else add("Not nested", true, "no bigger opposing zone around the entry");

  if (!S.f_react) add("Rejection candle", null, "filter off, the reaction is still shown on the card");
  else if (p.react === "waiting") add("Rejection candle", false, "price has not reached the zone yet, wait for a rejection candle");
  else if (p.react === "touched") add("Rejection candle", false, "price tagged the zone but has not printed a rejection candle");
  else add("Rejection candle", true, "rejection candle printed at the zone");

  return out;
}

export function contextLines(p: Play, nowMs = Date.now()): string[] {
  const out: string[] = [];
  if (p.barTs != null) {
    const age = (nowMs - p.barTs) / 60_000;
    out.push(`Last candle ${fmtAge(age)} ago (${fmtZone(p.barTs, SYD)} Sydney)`);
  }
  if (p.vwap != null && p.atr15) {
    const gap = (p.prox - p.vwap) / p.atr15;
    out.push(`Session VWAP ${fmt(p.vwap, p.nd)}, zone is ${gap >= 0 ? "+" : ""}${gap.toFixed(1)} ATR from it`);
  }
  if (p.rv != null) {
    out.push(`Volume ${p.rvBasis === "touch" ? "at the touch" : "approaching the zone"}: ${p.rv.toFixed(1)}x normal for this time of day`);
  }
  out.push(`Zone left by ${p.depart.toFixed(1)} ATR, formed about ${(p.ageBars / 4).toFixed(0)}h of trading ago${p.nested ? " · inside a bigger opposing zone" : ""}`);
  out.push({
    rejected: "Rejection candle printed at the zone",
    touched: "Price tagged the zone, no rejection candle yet",
    waiting: "Price has not reached the zone yet",
  }[p.react]);
  out.push("1h structure: " + ({ up: "higher highs and higher lows", down: "lower highs and lower lows", range: "sideways" }[p.htf]));
  if (p.us) {
    out.push(`Spread: ${p.spr == null ? "unknown" : `${p.spr.toFixed(3)}%`}`);
    if (p.newsOk === false) out.push("Headlines could not be read, so the headline check was skipped for this one");
    const recent = p.news.filter((n) => nowMs - n.t >= 0 && nowMs - n.t < 86_400_000);
    if (recent.length) {
      const latest = recent.reduce((a, b) => (a.t > b.t ? a : b));
      out.push(`Latest headline (${((nowMs - latest.t) / 3_600_000).toFixed(1)}h ago): "${latest.title.slice(0, 100)}"`);
    }
    const today = zonedParts(new Date(nowMs), NY).ymd;
    const soon = p.earn.find((d) => d >= today);
    if (soon) out.push(`Earnings ${soon}`);
  }
  return out;
}

export type Row = { play: Play; size: Size; tech: string[]; flt: string[] };

export function applyView(rows: Row[], S: Settings): Row[] {
  const out = rows.filter((r) => r.play.rr >= S.min_rr && (S.dir_f === "All" || r.play.side === S.dir_f.toLowerCase()));
  out.sort((a, b) => {
    const pa = a.play;
    const pb = b.play;
    if (S.sort_by === "Reward:risk") return pb.rr - pa.rr || pb.score - pa.score;
    if (S.sort_by === "Closest to entry") {
      const da = Math.abs(pa.px - pa.prox) / (pa.px || 1);
      const db = Math.abs(pb.px - pb.prox) / (pb.px || 1);
      return da - db || pb.score - pa.score;
    }
    if (S.sort_by === "Market") {
      return pa.market.localeCompare(pb.market) || pa.label.localeCompare(pb.label) || pb.score - pa.score;
    }
    return pb.score - pa.score || pb.rr - pa.rr;
  });
  return out;
}

export function evaluate(
  plays: Play[],
  S: Settings,
  ctx: Ctx,
  rate: (ccy: string, acct: string) => number | null,
  lim: LimitState | null,
  nowMs = Date.now(),
): Row[] {
  const rows: Row[] = [];
  for (const p of plays) {
    const lev = levOf(S, p.market);
    const sz = sizeOf(p, S.equity, S.risk_pct, lev, S.acct, rate(quoteCcy(p), S.acct));
    const nchecks = numberChecks(p, sz, lev, S);
    const fchecks = filterChecks(p, S, ctx, nowMs);
    let flt = fchecks.filter((c) => c.state === false).map((c) => c.detail);
    const checks = [...nchecks, ...fchecks];
    if (lim) {
      const halt = [...lim.halt];
      const extra = limitPlayReasons(lim, sz, S);
      flt = [...halt, ...flt, ...extra];
      if (S.f_limits) {
        const bad = [...halt, ...extra];
        checks.push({
          label: "Within your trading limits",
          state: bad.length === 0,
          detail: bad.join("; ") || "under every limit",
        });
      }
    }
    p.checks = checks;
    rows.push({
      play: p,
      size: sz,
      tech: nchecks.filter((c) => c.state === false).map((c) => c.detail),
      flt,
    });
  }
  return rows;
}

export const TRADE_FIELDS = [
  "id", "logged", "status", "tkr", "label", "market", "side", "entry", "stop", "target",
  "units", "risk", "fx", "acct", "rr", "score", "nd", "exit", "closed", "r", "pnl", "notes",
] as const;

export type Trade = {
  id: string;
  logged: string | null;
  status: "open" | "closed" | "cancelled";
  tkr: string;
  label: string;
  market: string;
  side: Side;
  entry: number;
  stop: number;
  target: number;
  units: number;
  risk: number;
  fx: number;
  acct: string;
  rr: number;
  score: number;
  nd: number;
  exit: number | null;
  closed: string | null;
  r: number | null;
  pnl: number | null;
  notes: string;
};

export function newTrade(p: Play, sz: Size, acct: string, now = new Date()): Trade {
  return {
    id: freshId(),
    logged: now.toISOString(),
    status: "open",
    tkr: p.tkr,
    label: p.label || p.tkr,
    market: p.market,
    side: p.side,
    entry: p.prox,
    stop: sz.stop,
    target: p.tgt,
    units: sz.units,
    risk: sz.loss,
    fx: sz.fx,
    acct,
    rr: p.rr,
    score: p.score,
    nd: p.nd,
    exit: null,
    closed: null,
    r: null,
    pnl: null,
    notes: "",
  };
}

export function tradeR(t: Trade, exitPrice: number): number {
  const riskPer = Math.abs(t.entry - t.stop);
  if (riskPer <= 0) return 0;
  const d = t.side === "long" ? 1 : -1;
  return (d * (exitPrice - t.entry)) / riskPer;
}

export function closeTrade(t: Trade, exitPrice: number, now = new Date()): Trade {
  const d = t.side === "long" ? 1 : -1;
  return {
    ...t,
    status: "closed",
    exit: exitPrice,
    closed: now.toISOString(),
    r: roundTo(tradeR(t, exitPrice), 3),
    pnl: roundTo(d * (exitPrice - t.entry) * t.units * t.fx, 2),
  };
}

export function cancelTrade(t: Trade, now = new Date()): Trade {
  return { ...t, status: "cancelled", closed: now.toISOString(), r: null, pnl: null, exit: null };
}

export function duplicateOpen(trades: Trade[], p: Play): boolean {
  return trades.some(
    (t) => t.status === "open" && t.tkr === p.tkr && t.side === p.side && Math.abs(t.entry - p.prox) <= 1e-9,
  );
}

export type JournalStats = {
  n: number;
  wins: number;
  losses: number;
  winRate: number;
  avgR: number;
  totalR: number;
  totalPnl: number;
  profitFactor: number | null;
  maxDdR: number;
  avgWinR: number;
  avgLossR: number;
  curve: number[];
  mixedAcct: boolean;
};

export function journalStats(trades: Trade[]): JournalStats {
  const cl = trades
    .filter((t) => t.status === "closed" && t.pnl != null && t.r != null && parseIso(t.closed))
    .sort((a, b) => (parseIso(a.closed)?.getTime() ?? 0) - (parseIso(b.closed)?.getTime() ?? 0));
  const empty: JournalStats = {
    n: 0, wins: 0, losses: 0, winRate: 0, avgR: 0, totalR: 0, totalPnl: 0,
    profitFactor: null, maxDdR: 0, avgWinR: 0, avgLossR: 0, curve: [], mixedAcct: false,
  };
  if (!cl.length) return empty;
  const wins = cl.filter((t) => (t.pnl ?? 0) > 0);
  const losses = cl.filter((t) => (t.pnl ?? 0) < 0);
  const grossW = wins.reduce((s, t) => s + (t.pnl ?? 0), 0);
  const grossL = -losses.reduce((s, t) => s + (t.pnl ?? 0), 0);
  const curve: number[] = [];
  let run = 0;
  let peak = 0;
  let dd = 0;
  for (const t of cl) {
    run += t.r ?? 0;
    peak = Math.max(peak, run);
    dd = Math.max(dd, peak - run);
    curve.push(roundTo(run, 3));
  }
  return {
    n: cl.length,
    wins: wins.length,
    losses: losses.length,
    winRate: (wins.length / cl.length) * 100,
    avgR: cl.reduce((s, t) => s + (t.r ?? 0), 0) / cl.length,
    totalR: run,
    totalPnl: cl.reduce((s, t) => s + (t.pnl ?? 0), 0),
    profitFactor: grossL > 0 ? grossW / grossL : null,
    maxDdR: dd,
    avgWinR: wins.length ? wins.reduce((s, t) => s + (t.r ?? 0), 0) / wins.length : 0,
    avgLossR: losses.length ? losses.reduce((s, t) => s + (t.r ?? 0), 0) / losses.length : 0,
    curve,
    mixedAcct: new Set(cl.map((t) => t.acct)).size > 1,
  };
}

function numOrNull(v: string): number | null {
  if (v.trim() === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function normalizeTrade(raw: Record<string, unknown>): Trade | null {
  try {
    const status = String(raw.status ?? "");
    const side = String(raw.side ?? "");
    const id = String(raw.id ?? "").trim();
    if ((status !== "open" && status !== "closed" && status !== "cancelled") || !id) return null;
    if (side !== "long" && side !== "short") return null;
    const entry = typeof raw.entry === "number" ? raw.entry : numOrNull(String(raw.entry ?? ""));
    const stop = typeof raw.stop === "number" ? raw.stop : numOrNull(String(raw.stop ?? ""));
    const units = typeof raw.units === "number" ? raw.units : numOrNull(String(raw.units ?? ""));
    const fx = typeof raw.fx === "number" ? raw.fx : numOrNull(String(raw.fx ?? ""));
    if (entry == null || stop == null || units == null || fx == null) return null;
    const num = (k: string) => {
      const v = raw[k];
      if (v == null || v === "") return null;
      if (typeof v === "number") return Number.isFinite(v) ? v : null;
      return numOrNull(String(v));
    };
    const int = (k: string, fallback = 0) => {
      const n = num(k);
      return n == null ? fallback : Math.trunc(n);
    };
    const logged = parseIso(raw.logged);
    const closed = parseIso(raw.closed);
    return {
      id: id.slice(0, 64),
      logged: logged ? logged.toISOString() : null,
      status,
      tkr: String(raw.tkr ?? "").slice(0, 32),
      label: String(raw.label ?? raw.tkr ?? "").slice(0, 64),
      market: String(raw.market ?? "").slice(0, 32),
      side,
      entry, stop,
      target: num("target") ?? entry,
      units, risk: num("risk") ?? 0, fx,
      acct: raw.acct === "USD" ? "USD" : "AUD",
      rr: num("rr") ?? 0,
      score: int("score"),
      nd: int("nd", 2),
      exit: num("exit"),
      closed: closed ? closed.toISOString() : null,
      r: num("r"),
      pnl: num("pnl"),
      notes: String(raw.notes ?? "").slice(0, 2000),
    };
  } catch {
    return null;
  }
}

function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cur = "";
  let q = false;
  const s = text.replace(/^\uFEFF/, "");
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (q) {
      if (c === '"') {
        if (s[i + 1] === '"') {
          cur += '"';
          i++;
        } else q = false;
      } else cur += c;
    } else if (c === '"') q = true;
    else if (c === ",") {
      row.push(cur);
      cur = "";
    } else if (c === "\n") {
      row.push(cur);
      rows.push(row);
      row = [];
      cur = "";
    } else if (c !== "\r") cur += c;
  }
  if (cur.length || row.length) {
    row.push(cur);
    rows.push(row);
  }
  const kept = rows.filter((r) => r.some((x) => x.trim() !== ""));
  if (!kept.length) return [];
  const header = kept[0].map((h) => h.trim());
  return kept.slice(1).map((r) => {
    const o: Record<string, string> = {};
    header.forEach((h, i) => {
      o[h] = r[i] ?? "";
    });
    return o;
  });
}

export function tradesFromCsv(text: string): Trade[] {
  const out: Trade[] = [];
  for (const row of parseCsv(text)) {
    const t = normalizeTrade(row);
    if (t) out.push(t);
  }
  return out;
}

export function tradesFromJson(text: string): Trade[] {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    return [];
  }
  if (!Array.isArray(data)) return [];
  const out: Trade[] = [];
  for (const row of data) {
    if (!row || typeof row !== "object") continue;
    const t = normalizeTrade(row as Record<string, unknown>);
    if (t) out.push(t);
  }
  return out;
}

export function tradesToCsv(trades: Trade[]): string {
  const esc = (v: unknown) => {
    if (v == null) return "";
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [TRADE_FIELDS.join(",")];
  for (const t of trades) {
    lines.push(TRADE_FIELDS.map((k) => esc(t[k])).join(","));
  }
  return lines.join("\n");
}

export function mergeTrades(existing: Trade[], incoming: Trade[]): { trades: Trade[]; added: number } {
  const have = new Set(existing.map((t) => t.id));
  const neu = incoming.filter((t) => !have.has(t.id));
  return { trades: [...existing, ...neu], added: neu.length };
}

export type LimitState = {
  halt: string[];
  openN: number;
  openRisk: number;
  dayPnl: number;
  lossCap: number;
  riskCap: number;
  maxOpen: number;
  cur: string;
};

export function limitState(trades: Trade[], S: Settings, nowMs = Date.now()): LimitState {
  const now = new Date(nowMs);
  const today = zonedParts(now, SYD).ymd;
  const cur = S.acct === "AUD" ? "A$" : "$";
  const openT = trades.filter((t) => t.status === "open");
  let dayPnl = 0;
  for (const t of trades) {
    if (t.status !== "closed" || t.pnl == null) continue;
    const closed = parseIso(t.closed);
    if (!closed) continue;
    if (zonedParts(closed, SYD).ymd === today) dayPnl += t.pnl;
  }
  const lim: LimitState = {
    halt: [],
    openN: openT.length,
    openRisk: openT.reduce((s, t) => s + (Number.isFinite(t.risk) ? t.risk : 0), 0),
    dayPnl,
    lossCap: S.equity * S.day_loss_pct / 100,
    riskCap: S.equity * S.max_open_risk / 100,
    maxOpen: Math.trunc(S.max_open),
    cur,
  };
  if (!S.f_limits) return lim;
  if (dayPnl <= -lim.lossCap) {
    lim.halt.push(`daily loss limit reached: ${money(cur, dayPnl)} today (limit ${money(cur, -lim.lossCap)}), stop for the day`);
  }
  if (lim.openN >= lim.maxOpen) lim.halt.push(`${lim.openN} trades already open (limit ${lim.maxOpen})`);
  else if (lim.openRisk >= lim.riskCap) {
    lim.halt.push(`open risk ${money(cur, lim.openRisk)} is at your limit of ${money(cur, lim.riskCap)}`);
  }
  return lim;
}

export function limitPlayReasons(lim: LimitState, sz: Size, S: Settings): string[] {
  if (!S.f_limits || lim.halt.length) return [];
  if (lim.openRisk + sz.loss > lim.riskCap) {
    return [`taking it would lift open risk to ${money(lim.cur, lim.openRisk + sz.loss)} (limit ${money(lim.cur, lim.riskCap)})`];
  }
  return [];
}

export function alertLines(rows: Row[], limit = 6): string {
  const lines = rows.slice(0, limit).map(({ play: p, size: sz }) =>
    `${p.side === "long" ? "BUY" : "SELL SHORT"} ${p.label} @ ${fmt(p.prox, p.nd)} stop ${fmt(sz.stop, p.nd)} target ${fmt(p.tgt, p.nd)} ${p.rr.toFixed(1)}R`);
  if (rows.length > limit) lines.push(`and ${rows.length - limit} more`);
  return lines.join("\n");
}

export function freshId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID().replace(/-/g, "").slice(0, 8);
  return Math.random().toString(16).slice(2, 10);
}
