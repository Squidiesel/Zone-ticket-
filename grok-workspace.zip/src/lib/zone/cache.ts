/** Insertion-order TTL cache. Evicts the oldest key. No full-map sort on overflow. */
export class TtlCache<V> {
  private map = new Map<string, { t: number; v: V }>();
  constructor(private max = 400) {}

  get(key: string, ttlMs: number, now = Date.now()): V | undefined {
    const hit = this.map.get(key);
    if (!hit) return undefined;
    if (now - hit.t >= ttlMs) {
      this.map.delete(key);
      return undefined;
    }
    this.map.delete(key);
    this.map.set(key, hit);
    return hit.v;
  }

  set(key: string, v: V, now = Date.now()) {
    this.map.delete(key);
    this.map.set(key, { t: now, v });
    while (this.map.size > this.max) {
      const oldest = this.map.keys().next().value;
      if (oldest === undefined) break;
      this.map.delete(oldest);
    }
  }

  get size() {
    return this.map.size;
  }

  keys() {
    return [...this.map.keys()];
  }
}
