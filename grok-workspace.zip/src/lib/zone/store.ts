import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

import {
  type Play,
  type Row,
  type Trade,
  cancelTrade,
  closeTrade,
  duplicateOpen,
  freshId,
  mergeTrades,
  newTrade,
  tradesFromCsv,
  tradesFromJson,
} from "@/lib/zone/engine";
import { DEFAULTS, type Settings, codeToSettings } from "@/lib/zone/markets";
import type { Ctx } from "@/lib/zone/engine";

export type ScanSnap = {
  ts: number;
  plays: Play[];
  errors: string[];
  n: number;
  skippedUs: number;
  secs: number;
  ctx: Ctx;
  rates: Record<string, number>;
  hits: number;
  misses: number;
  earnOk: boolean;
  running: boolean;
};

type Desk = {
  settings: Settings;
  journal: Trade[];
  scan: ScanSnap | null;
  fmpKey: string;
  flash: string | null;
  setSetting: <K extends keyof Settings>(key: K, value: Settings[K]) => void;
  patchSettings: (patch: Partial<Settings>) => void;
  resetSettings: () => void;
  applyCode: (code: string) => void;
  setFmpKey: (v: string) => void;
  setFlash: (v: string | null) => void;
  setScan: (scan: ScanSnap | null) => void;
  logPlay: (p: Play, row: Row) => void;
  closeById: (id: string, exitPrice: number) => void;
  cancelById: (id: string) => void;
  importText: (text: string, json: boolean) => void;
};

const memory = new Map<string, string>();

function safeStorage(): Pick<Storage, "getItem" | "setItem" | "removeItem"> {
  return {
    getItem: (k) => {
      try {
        if (typeof localStorage !== "undefined") return localStorage.getItem(k);
      } catch {
        /* private mode */
      }
      return memory.get(k) ?? null;
    },
    setItem: (k, v) => {
      try {
        if (typeof localStorage !== "undefined") {
          localStorage.setItem(k, v);
          return;
        }
      } catch {
        /* quota */
      }
      memory.set(k, v);
    },
    removeItem: (k) => {
      try {
        if (typeof localStorage !== "undefined") localStorage.removeItem(k);
      } catch {
        /* ignore */
      }
      memory.delete(k);
    },
  };
}

export const useDesk = create<Desk>()(
  persist(
    (set, get) => ({
      settings: DEFAULTS,
      journal: [],
      scan: null,
      fmpKey: "",
      flash: null,
      setSetting: (key, value) => set({ settings: { ...get().settings, [key]: value } }),
      patchSettings: (patch) => set({ settings: { ...get().settings, ...patch } }),
      resetSettings: () => set({ settings: { ...DEFAULTS }, flash: "Settings reset. The journal was kept." }),
      applyCode: (code) => {
        const patch = codeToSettings(code);
        set({
          settings: { ...get().settings, ...patch },
          flash: `Applied ${Object.keys(patch).length} settings. They stay on this phone.`,
        });
      },
      setFmpKey: (v) => set({ fmpKey: v }),
      setFlash: (v) => set({ flash: v }),
      setScan: (scan) => set({ scan }),
      logPlay: (p, row) => {
        const journal = get().journal;
        if (duplicateOpen(journal, p)) {
          set({ flash: `${p.label} is already in your open trades at that price.` });
          return;
        }
        const t = { ...newTrade(p, row.size, get().settings.acct), id: freshId() };
        set({ journal: [...journal, t], flash: `Logged ${p.label}. It is in the Journal tab.` });
      },
      closeById: (id, exitPrice) => {
        const journal = get().journal.map((t) => {
          if (t.id !== id || t.status !== "open") return t;
          return closeTrade(t, exitPrice);
        });
        const t = journal.find((x) => x.id === id);
        const cur = t?.acct === "AUD" ? "A$" : "$";
        set({
          journal,
          flash: t && t.status === "closed"
            ? `Closed ${t.label}: ${t.r != null && t.r >= 0 ? "+" : ""}${(t.r ?? 0).toFixed(2)}R, ${t.pnl != null && t.pnl < 0 ? "-" : ""}${cur}${Math.abs(t.pnl ?? 0).toLocaleString("en-US", { maximumFractionDigits: 0 })}`
            : "Trade updated.",
        });
      },
      cancelById: (id) => {
        let label = "Trade";
        const journal = get().journal.map((t) => {
          if (t.id !== id || t.status !== "open") return t;
          label = t.label;
          return cancelTrade(t);
        });
        set({ journal, flash: `Removed ${label} (never filled).` });
      },
      importText: (text, json) => {
        const incoming = json ? tradesFromJson(text) : tradesFromCsv(text);
        if (!incoming.length) {
          set({ flash: "Could not read that file." });
          return;
        }
        const { trades, added } = mergeTrades(get().journal, incoming);
        const skipped = incoming.length - added;
        set({
          journal: trades,
          flash: `Imported ${added} new trade${added === 1 ? "" : "s"}${skipped ? `, ${skipped} already there` : ""}. Rows with a bad date were left out.`,
        });
      },
    }),
    {
      name: "zone-ticket-desk",
      skipHydration: true,
      storage: createJSONStorage(safeStorage),
      partialize: (s) => ({ settings: s.settings, journal: s.journal, scan: s.scan }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<Pick<Desk, "settings" | "journal" | "scan">>;
        const scan = p.scan ? { ...p.scan, running: false } : null;
        return {
          ...current,
          settings: { ...current.settings, ...(p.settings ?? {}) },
          journal: Array.isArray(p.journal) ? p.journal : [],
          scan,
        };
      },
    },
  ),
);
