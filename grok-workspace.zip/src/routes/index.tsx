import { createFileRoute } from "@tanstack/react-router";

import { ZoneApp } from "@/components/zone/zone-app";

export const Route = createFileRoute("/")({ component: ZoneApp });
