import type { ReactNode } from "react";
import { CHECK_WHY } from "@/lib/zone/markets";
import { contextLines, fmt, money, zonePoints, type Play, type Row } from "@/lib/zone/engine";
import { useDesk } from "@/lib/zone/store";

export function PlayCard({ row }: { row: Row }) {
  const logPlay = useDesk((s) => s.logPlay);
  const { play: p, size: s, tech, flt } = row;
  const why = [...tech, ...flt];
  const long = p.side === "long";
  const dist = p.px ? (Math.abs(p.px - p.prox) / p.px) * 100 : 0;
  const cur = s.cur;
  return (
    <article className="rounded-2xl border border-line bg-panel p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium tracking-wide text-muted uppercase">
            {long ? "Buy" : "Sell short"} · {long ? "Demand" : "Supply"}
          </p>
          <h3 className="mt-1 text-lg font-semibold leading-tight">{p.label}</h3>
        </div>
        <p className="font-mono text-sm text-copper">{p.rr.toFixed(1)} : 1</p>
      </div>
      <p className="mt-3 font-mono text-3xl leading-none tracking-tight">{fmt(p.prox, p.nd)}</p>
      <p className="mt-2 text-sm text-muted">
        Limit at the zone, {dist.toFixed(1)}% from the last price. Score {p.score}/5.
      </p>
      <dl className="mt-4 grid grid-cols-3 gap-2">
        <Stat label="Stop" value={fmt(s.stop, p.nd)} />
        <Stat label={long ? "Sell target" : "Cover target"} value={fmt(p.tgt, p.nd)} />
        <Stat label="Units" value={s.units.toLocaleString("en-US")} />
        <Stat label="Margin" value={money(cur, s.margin)} />
        <Stat label="Loss at stop" value={money(cur, s.loss)} />
        <Stat label="Gain at target" value={money(cur, s.gain)} />
      </dl>
      <p className="mt-3 text-sm text-muted">
        Leverage used {s.lev.toFixed(1)}x
        {p.kind === "forex" ? ` · about ${(s.units / 100000).toFixed(2)} standard lots` : ""}
      </p>
      {s.approx ? (
        <p className="mt-2 text-sm text-copper">
          Could not read the {s.ccy} to {s.acct} rate, so size and margin are approximate.
        </p>
      ) : null}
      <ul className="mt-3 grid gap-1 text-sm text-muted">
        {contextLines(p).map((line) => (
          <li key={line}>{line}</li>
        ))}
      </ul>
      {why.length === 0 ? (
        <p className="mt-4 rounded-xl bg-up/15 px-3 py-2 text-sm text-up">Take. Every check passes.</p>
      ) : (
        <p className="mt-4 rounded-xl bg-copper/15 px-3 py-2 text-sm text-copper">Skip for now: {why.join("; ")}.</p>
      )}
      <Checks play={p} />
      <button
        type="button"
        className="mt-4 min-h-11 w-full rounded-xl bg-copper px-4 text-sm font-semibold text-copper-ink disabled:opacity-40"
        disabled={s.units < 1}
        onClick={() => logPlay(p, row)}
      >
        Log this trade
      </button>
    </article>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-paper px-2 py-2">
      <dt className="text-xs text-faint">{label}</dt>
      <dd className="mt-1 font-mono text-sm text-ink">{value}</dd>
    </div>
  );
}

function Checks({ play }: { play: Play }) {
  const checks = play.checks ?? [];
  if (!checks.length) return null;
  const pts = zonePoints(play);
  return (
    <details className="mt-3 rounded-xl border border-line">
      <summary className="min-h-11 cursor-pointer px-3 py-3 text-sm font-medium">Every check</summary>
      <ul className="grid gap-3 px-3 pb-3">
        {checks.map((c) => (
          <li key={c.label} className="text-sm">
            <p>
              <Mark state={c.state} /> <span className="font-medium">{c.label}.</span>{" "}
              <span className="text-muted">{c.detail}</span>
            </p>
            {c.state === false && CHECK_WHY[c.label] ? (
              <p className="mt-1 text-faint">Why it matters: {CHECK_WHY[c.label]}</p>
            ) : null}
          </li>
        ))}
        {pts.length ? (
          <li className="text-sm text-muted">
            Zone points: {pts.map(([lab, ok]) => `${ok ? "Yes" : "No"} ${lab}`).join(" · ")}
          </li>
        ) : null}
      </ul>
    </details>
  );
}

function Mark({ state }: { state: boolean | null }) {
  if (state === true) return <span className="font-mono text-xs text-up">PASS</span>;
  if (state === false) return <span className="font-mono text-xs text-down">FAIL</span>;
  return <span className="font-mono text-xs text-faint">OFF</span>;
}

export function Banner({
  tone,
  children,
}: {
  tone: "info" | "warn" | "bad" | "good";
  children: ReactNode;
}) {
  const cls = {
    info: "bg-panel text-muted",
    warn: "bg-copper/15 text-copper",
    bad: "bg-down/15 text-down",
    good: "bg-up/15 text-up",
  }[tone];
  return <p className={`rounded-xl px-3 py-2 text-sm ${cls}`}>{children}</p>;
}
