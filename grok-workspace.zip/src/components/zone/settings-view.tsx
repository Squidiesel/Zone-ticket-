import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";

import { sendAlertFn } from "@/lib/zone/api.server";
import { BOUNDS, CHECK_WHY, MARKET_NAMES, clampKey, settingsToCode, validTopic, type Settings } from "@/lib/zone/markets";
import { useDesk } from "@/lib/zone/store";
import { priceTtlLabel } from "@/lib/zone/time";

export function SettingsView() {
  const settings = useDesk((s) => s.settings);
  const setSetting = useDesk((s) => s.setSetting);
  const resetSettings = useDesk((s) => s.resetSettings);
  const applyCode = useDesk((s) => s.applyCode);
  const setFlash = useDesk((s) => s.setFlash);
  const fmpKey = useDesk((s) => s.fmpKey);
  const setFmpKey = useDesk((s) => s.setFmpKey);
  const sendAlert = useServerFn(sendAlertFn);
  const [code, setCode] = useState("");
  const topicOk = validTopic(settings.ntfy_topic);

  return (
    <div className="grid gap-4">
      <details open className="rounded-2xl border border-line bg-panel">
        <summary className="min-h-11 cursor-pointer px-4 py-3 font-medium">Account</summary>
        <div className="grid gap-3 px-4 pb-4">
          <label className="grid gap-1 text-sm">
            <span className="text-faint">Account currency</span>
            <select
              className="min-h-11 rounded-xl border border-line bg-paper px-3"
              value={settings.acct}
              onChange={(e) => setSetting("acct", e.target.value === "USD" ? "USD" : "AUD")}
            >
              <option value="AUD">AUD</option>
              <option value="USD">USD</option>
            </select>
          </label>
          <Num k="equity" label="Account equity" step={500} />
          <Num k="risk_pct" label="Risk per trade (%)" step={0.25} />
          <p className="text-sm text-faint">Leverage limits. Defaults are typical Australian retail limits. Use your broker's real numbers.</p>
          {MARKET_NAMES.map((m) => (
            <Num key={m} k={`lev_${m}` as keyof Settings} label={`${m} max leverage (x)`} step={1} />
          ))}
        </div>
      </details>

      <details className="rounded-2xl border border-line bg-panel">
        <summary className="min-h-11 cursor-pointer px-4 py-3 font-medium">Watchlist</summary>
        <div className="grid gap-3 px-4 pb-4">
          <label className="grid gap-1 text-sm">
            <span className="text-faint">Stock tickers, separated by spaces</span>
            <textarea className="min-h-28 rounded-xl border border-line bg-paper px-3 py-3 text-base" value={settings.watch} onChange={(e) => setSetting("watch", e.target.value)} />
          </label>
          <label className="grid gap-1 text-sm">
            <span className="text-faint">Extra symbols, every scan</span>
            <textarea
              className="min-h-20 rounded-xl border border-line bg-paper px-3 py-3 text-base"
              placeholder="AUDNZD=X  NG=F  BTC-USD"
              value={settings.extras}
              onChange={(e) => setSetting("extras", e.target.value)}
            />
          </label>
        </div>
      </details>

      <details className="rounded-2xl border border-line bg-panel" open>
        <summary className="min-h-11 cursor-pointer px-4 py-3 font-medium">What counts as a take</summary>
        <div className="grid gap-3 px-4 pb-4">
          <Num k="min_score" label="Minimum zone score (out of 5)" step={1} />
          <Num k="min_rr_take" label="Minimum reward : risk" step={0.5} />
          <Num k="max_dist" label="How far from price to look (15m ATR)" step={1} />
          <Num k="per_inst" label="Plays kept per instrument" step={1} />
          <p className="text-sm text-faint">Each filter can hold a play back. Turn one off to see what it was hiding.</p>
          <Toggle k="f_events" label="Event blackouts (FOMC, CPI, jobs, your own times)" />
          <Num k="ev_min" label="Blackout window, minutes either side" step={5} />
          <label className="grid gap-1 text-sm">
            <span className="text-faint">Your own blackout times, Sydney, one per line</span>
            <textarea
              className="min-h-20 rounded-xl border border-line bg-paper px-3 py-3 text-base"
              placeholder="2026-10-22 23:30 US CPI"
              value={settings.manual_ev}
              onChange={(e) => setSetting("manual_ev", e.target.value)}
            />
          </label>
          <label className="grid gap-1 text-sm">
            <span className="text-faint">FMP API key, this visit only</span>
            <input
              type="password"
              className="min-h-11 rounded-xl border border-line bg-paper px-3 text-base"
              value={fmpKey}
              onChange={(e) => setFmpKey(e.target.value)}
              autoComplete="off"
            />
          </label>
          <Toggle k="f_stale" label="Block stale data" />
          <Num k="stale_min" label="Stale after (minutes)" step={5} />
          <Toggle k="f_news" label="Headline check for US stocks and ETFs" />
          <Num k="news_hrs" label="Headline window, hours" step={0.5} />
          <Toggle k="f_earn" label="Block earnings day and the day after" />
          <Toggle k="f_rvol" label="Block weak volume at the zone" />
          <Num k="rv_weak" label="Weak volume below (x normal)" step={0.1} />
          <Num k="max_spread" label="Max bid-ask spread for US names (%)" step={0.01} />
          <Toggle k="f_vwap" label="Session VWAP side" />
          <Num k="vwap_tol" label="Wrong side of VWAP allowed (15m ATR)" step={0.25} />
          <Toggle k="f_htf" label="Block counter-trend plays (1h structure)" />
          <Toggle k="f_index" label="Hold plays while SPY or QQQ is impulsive" />
          <Toggle k="f_depart" label="Zone must have left strongly" />
          <Num k="zq_depart" label="Minimum departure (ATR)" step={0.5} />
          <Toggle k="f_age" label="Block old zones" />
          <Num k="zq_age" label="Oldest zone allowed (hours of trading)" step={4} />
          <Toggle k="f_nest" label="Block zones inside a bigger opposing zone" />
          <Toggle k="f_react" label="Only take after a rejection candle" />
          <Toggle k="f_limits" label="Enforce trading limits from the journal" />
          <Num k="day_loss_pct" label="Daily loss limit (% of equity, Sydney day)" step={0.5} />
          <Num k="max_open" label="Max open trades" step={1} />
          <Num k="max_open_risk" label="Max total open risk (% of equity)" step={0.5} />
        </div>
      </details>

      <details className="rounded-2xl border border-line bg-panel">
        <summary className="min-h-11 cursor-pointer px-4 py-3 font-medium">Phone alerts</summary>
        <div className="grid gap-3 px-4 pb-4">
          <Toggle k="alerts_on" label="Push when a new take appears" />
          <label className="grid gap-1 text-sm">
            <span className="text-faint">ntfy topic</span>
            <input
              type="password"
              className="min-h-11 rounded-xl border border-line bg-paper px-3 text-base"
              value={settings.ntfy_topic}
              onChange={(e) => setSetting("ntfy_topic", e.target.value)}
              autoComplete="off"
            />
          </label>
          <p className="text-sm text-faint">
            Install the free ntfy app, subscribe to a long random topic, and enter that name here. Anyone who knows it can read your alerts.
          </p>
          <button
            type="button"
            className="min-h-11 rounded-xl border border-line text-sm disabled:opacity-40"
            disabled={!topicOk}
            onClick={() => {
              void sendAlert({ data: { topic: settings.ntfy_topic.trim(), title: "Zone Ticket test", body: "Alerts are working." } })
                .then(() => setFlash("Test alert sent. Check your phone."))
                .catch((e: unknown) => setFlash(e instanceof Error ? `Test alert failed: ${e.message}` : "Test alert failed."));
            }}
          >
            Send test alert
          </button>
          <label className="flex min-h-11 items-center justify-between gap-3 text-sm">
            <span>Rescan every hour while this page is open</span>
            <input type="checkbox" className="size-5 accent-copper" checked={settings.auto} onChange={(e) => setSetting("auto", e.target.checked)} />
          </label>
        </div>
      </details>

      <details className="rounded-2xl border border-line bg-panel">
        <summary className="min-h-11 cursor-pointer px-4 py-3 font-medium">Data freshness</summary>
        <div className="grid gap-2 px-4 pb-4 text-sm text-muted">
          <p>{priceTtlLabel()}.</p>
          <p>Scans run four names at a time. If Yahoo answers too many requests, that name waits and tries again instead of failing the whole list.</p>
          <p>The US cash session is judged on the New York clock, weekday 9:30 to 16:00. A weekend or a Sydney offset cannot mark it open.</p>
          <p>Imported journal rows with a date that is not a real timestamp are skipped. They cannot crash the page.</p>
        </div>
      </details>

      <details className="rounded-2xl border border-line bg-panel">
        <summary className="min-h-11 cursor-pointer px-4 py-3 font-medium">Move settings</summary>
        <div className="grid gap-3 px-4 pb-4">
          <p className="text-sm text-faint">Settings stay on this phone. Copy this code to another device. It includes your ntfy topic, so keep it private.</p>
          <textarea readOnly className="min-h-24 rounded-xl border border-line bg-paper px-3 py-3 font-mono text-xs" value={settingsToCode(settings)} />
          <label className="grid gap-1 text-sm">
            <span className="text-faint">Paste a settings code</span>
            <textarea className="min-h-20 rounded-xl border border-line bg-paper px-3 py-3 font-mono text-xs" value={code} onChange={(e) => setCode(e.target.value)} />
          </label>
          <button
            type="button"
            className="min-h-11 rounded-xl border border-line text-sm disabled:opacity-40"
            disabled={!code.trim()}
            onClick={() => {
              try {
                applyCode(code);
                setCode("");
              } catch (e) {
                setFlash(e instanceof Error ? e.message : "Could not apply that code.");
              }
            }}
          >
            Apply code
          </button>
          <button type="button" className="min-h-11 rounded-xl border border-line text-sm" onClick={() => resetSettings()}>
            Reset settings
          </button>
        </div>
      </details>

      <details className="rounded-2xl border border-line bg-panel">
        <summary className="min-h-11 cursor-pointer px-4 py-3 font-medium">Why a play is take or blocked</summary>
        <ul className="grid gap-3 px-4 pb-4">
          {Object.entries(CHECK_WHY).map(([label, why]) => (
            <li key={label} className="text-sm">
              <span className="font-medium">{label}.</span> <span className="text-muted">{why}</span>
            </li>
          ))}
        </ul>
      </details>
    </div>
  );
}

function Num({ k, label, step }: { k: keyof Settings; label: string; step: number }) {
  const settings = useDesk((s) => s.settings);
  const setSetting = useDesk((s) => s.setSetting);
  const bounds = BOUNDS[k] ?? [0, 1e9];
  const value = settings[k];
  return (
    <label className="grid gap-1 text-sm">
      <span className="text-faint">{label}</span>
      <input
        type="number"
        className="min-h-11 rounded-xl border border-line bg-paper px-3 font-mono text-base text-ink"
        min={bounds[0]}
        max={bounds[1]}
        step={step}
        value={typeof value === "number" ? value : 0}
        onChange={(e) => {
          const n = Number(e.target.value);
          if (!Number.isFinite(n)) return;
          setSetting(k, clampKey(k, n) as never);
        }}
      />
    </label>
  );
}

function Toggle({ k, label }: { k: keyof Settings; label: string }) {
  const settings = useDesk((s) => s.settings);
  const setSetting = useDesk((s) => s.setSetting);
  const on = Boolean(settings[k]);
  return (
    <label className="flex min-h-11 items-center justify-between gap-3 text-sm">
      <span>{label}</span>
      <input
        type="checkbox"
        className="size-5 accent-copper"
        checked={on}
        onChange={(e) => setSetting(k, e.target.checked as never)}
      />
    </label>
  );
}
