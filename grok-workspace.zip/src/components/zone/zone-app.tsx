import { useEffect, useState } from "react";

import { JournalView } from "@/components/zone/journal-view";
import { ScanView } from "@/components/zone/scan-view";
import { SettingsView } from "@/components/zone/settings-view";
import { TickerView } from "@/components/zone/ticker-view";
import { useDesk } from "@/lib/zone/store";
import { fmtZone, SYD } from "@/lib/zone/time";

const TABS = [
  { id: "scan", label: "Scan" },
  { id: "ticker", label: "Ticker" },
  { id: "journal", label: "Journal" },
  { id: "setup", label: "Setup" },
] as const;

type Tab = (typeof TABS)[number]["id"];

export function ZoneApp() {
  const [tab, setTab] = useState<Tab>("scan");
  const [now, setNow] = useState<number | null>(null);
  const flash = useDesk((s) => s.flash);
  const setFlash = useDesk((s) => s.setFlash);

  useEffect(() => {
    void useDesk.persist.rehydrate();
    const tick = () => setNow(Date.now());
    tick();
    const id = window.setInterval(tick, 30_000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (!flash) return;
    const id = window.setTimeout(() => setFlash(null), 4200);
    return () => window.clearTimeout(id);
  }, [flash, setFlash]);

  return (
    <main className="mx-auto min-h-screen w-full max-w-3xl px-4 pb-16 pt-5">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="font-mono text-xs tracking-widest text-copper">ZONE TICKET</p>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight">Supply and demand levels</h1>
        </div>
        <p className="pb-1 text-right font-mono text-xs text-faint">
          {now ? fmtZone(now, SYD) : "Sydney"}
          <span className="block">Sydney</span>
        </p>
      </header>
      {flash ? (
        <p role="status" className="mt-4 rounded-xl bg-panel px-3 py-3 text-sm text-ink">{flash}</p>
      ) : null}
      <nav className="sticky top-0 z-10 -mx-4 mt-4 grid grid-cols-4 gap-1 border-b border-line bg-paper/95 px-4 py-2 backdrop-blur">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            aria-current={tab === t.id ? "page" : undefined}
            className={`min-h-11 rounded-xl text-sm ${tab === t.id ? "bg-panel font-semibold text-ink" : "text-muted"}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </nav>
      <div className="mt-4">
        <div className={tab === "scan" ? "" : "hidden"}>
          <ScanView />
        </div>
        <div className={tab === "ticker" ? "" : "hidden"}>
          <TickerView />
        </div>
        <div className={tab === "journal" ? "" : "hidden"}>
          <JournalView />
        </div>
        <div className={tab === "setup" ? "" : "hidden"}>
          <SettingsView />
        </div>
      </div>
      <p className="mt-10 text-sm text-faint">
        Leveraged products lose money for most retail traders. Test on a demo account first. This is a calculator, not financial advice.
      </p>
    </main>
  );
}
