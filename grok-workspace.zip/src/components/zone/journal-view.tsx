import { useState } from "react";
import { Line, LineChart, ResponsiveContainer, YAxis } from "recharts";

import { Banner } from "@/components/zone/play-card";
import { fmt, journalStats, limitState, money, tradesToCsv, type Trade } from "@/lib/zone/engine";
import { useDesk } from "@/lib/zone/store";
import { fmtZone, parseIso, SYD } from "@/lib/zone/time";

export function JournalView() {
  const settings = useDesk((s) => s.settings);
  const journal = useDesk((s) => s.journal);
  const closeById = useDesk((s) => s.closeById);
  const cancelById = useDesk((s) => s.cancelById);
  const importText = useDesk((s) => s.importText);
  const cur = settings.acct === "AUD" ? "A$" : "$";
  const lim = limitState(journal, settings);
  const stats = journalStats(journal);
  const openT = journal.filter((t) => t.status === "open");
  const closed = journal
    .filter((t) => t.status === "closed")
    .sort((a, b) => (parseIso(b.closed)?.getTime() ?? 0) - (parseIso(a.closed)?.getTime() ?? 0));

  return (
    <div className="grid gap-5">
      <p className="text-sm text-muted">
        Log a trade from any play. Close it here when you exit. Limits and results come from this list, using the Sydney day.
      </p>
      {settings.f_limits && lim.halt.length ? <Banner tone="bad">{`Trading limits: ${lim.halt.join("; ")}.`}</Banner> : null}
      <div className="grid grid-cols-3 gap-2">
        <Metric label="Today" value={money(cur, lim.dayPnl)} />
        <Metric label="Open" value={`${lim.openN} / ${lim.maxOpen}`} />
        <Metric label="Open risk" value={money(cur, lim.openRisk)} />
      </div>
      <section className="grid gap-3">
        <h2 className="text-base font-semibold">Results</h2>
        {stats.n === 0 ? <Banner tone="info">No closed trades yet. Results appear here once you close some.</Banner> : (
          <>
            <div className="grid grid-cols-3 gap-2">
              <Metric label="Closed" value={String(stats.n)} />
              <Metric label="Win rate" value={`${stats.winRate.toFixed(0)}%`} />
              <Metric label="Average R" value={`${stats.avgR >= 0 ? "+" : ""}${stats.avgR.toFixed(2)}`} />
            </div>
            <div className="grid grid-cols-3 gap-2">
              <Metric label="Total P&L" value={money(cur, stats.totalPnl)} />
              <Metric label="Profit factor" value={stats.profitFactor == null ? "n/a" : stats.profitFactor.toFixed(2)} />
              <Metric label="Max drawdown" value={`${stats.maxDdR.toFixed(1)}R`} />
            </div>
            <p className="text-sm text-faint">
              Average win {stats.avgWinR >= 0 ? "+" : ""}{stats.avgWinR.toFixed(2)}R · average loss {stats.avgLossR.toFixed(2)}R · total {stats.totalR >= 0 ? "+" : ""}{stats.totalR.toFixed(1)}R
            </p>
            {stats.mixedAcct ? <p className="text-sm text-copper">These closes mix account currencies, so the cash total is only a rough sum.</p> : null}
            {stats.curve.length >= 2 ? (
              <div className="h-36 rounded-2xl border border-line bg-panel px-2 py-3">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={stats.curve.map((v, i) => ({ i, v }))}>
                    <YAxis hide domain={["auto", "auto"]} />
                    <Line type="monotone" dataKey="v" stroke="var(--color-copper)" dot={false} strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : null}
            {stats.n < 30 ? <p className="text-sm text-faint">Under 30 closed trades is too few to trust win rate or profit factor.</p> : null}
          </>
        )}
      </section>
      <section className="grid gap-3">
        <h2 className="text-base font-semibold">Open trades</h2>
        {openT.length === 0 ? <Banner tone="info">Nothing open.</Banner> : openT.map((t) => (
          <OpenTrade key={t.id} t={t} cur={cur} onClose={closeById} onCancel={cancelById} />
        ))}
      </section>
      {closed.length ? (
        <section className="grid gap-2">
          <h2 className="text-base font-semibold">Closed trades</h2>
          <div className="overflow-x-auto rounded-2xl border border-line">
            <table className="w-full min-w-xl text-left text-sm">
              <thead className="text-faint">
                <tr>
                  {["Closed", "Instrument", "Side", "R", "P&L"].map((h) => (
                    <th key={h} className="px-3 py-2 font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {closed.map((t) => (
                  <tr key={t.id} className="border-t border-line">
                    <td className="px-3 py-2 text-muted">{t.closed && parseIso(t.closed) ? fmtZone(parseIso(t.closed)!.getTime(), SYD, { day: true }) : "date unreadable"}</td>
                    <td className="px-3 py-2">{t.label}</td>
                    <td className="px-3 py-2">{t.side}</td>
                    <td className="px-3 py-2 font-mono">{t.r == null ? "" : t.r.toFixed(2)}</td>
                    <td className="px-3 py-2 font-mono">{t.pnl == null ? "" : money(cur, t.pnl)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ) : null}
      <section className="grid gap-2">
        <h2 className="text-base font-semibold">Backup</h2>
        <p className="text-sm text-faint">
          The journal stays in this browser. Download a copy before you clear site data. A row with a broken date is skipped on import and does not wipe the rest.
        </p>
        {journal.length ? (
          <button
            type="button"
            className="min-h-11 rounded-xl border border-line text-sm font-medium"
            onClick={() => {
              const url = URL.createObjectURL(new Blob([tradesToCsv(journal)], { type: "text/csv" }));
              const a = document.createElement("a");
              a.href = url;
              a.download = "zone-ticket-journal.csv";
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            Download journal (CSV)
          </button>
        ) : null}
        <label className="grid gap-1 text-sm">
          <span className="text-faint">Restore from CSV or JSON</span>
          <input
            className="text-sm file:mr-3 file:min-h-11 file:rounded-xl file:border-0 file:bg-panel file:px-3 file:text-ink"
            type="file"
            accept=".csv,.json,text/csv,application/json"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              e.target.value = "";
              if (!file) return;
              const text = await file.text();
              importText(text, file.name.toLowerCase().endsWith(".json") || text.trim().startsWith("["));
            }}
          />
        </label>
      </section>
    </div>
  );
}

function OpenTrade({
  t,
  cur,
  onClose,
  onCancel,
}: {
  t: Trade;
  cur: string;
  onClose: (id: string, px: number) => void;
  onCancel: (id: string) => void;
}) {
  const [px, setPx] = useState(String(t.entry));
  const nd = t.nd || 2;
  const logged = parseIso(t.logged);
  return (
    <article className="rounded-2xl border border-line bg-panel p-4">
      <h3 className="font-semibold">{t.side === "long" ? "Buy" : "Sell short"} {t.label}</h3>
      <p className="mt-1 font-mono text-xl">{fmt(t.entry, nd)}</p>
      <p className="mt-1 text-sm text-muted">
        Stop {fmt(t.stop, nd)} · target {fmt(t.target, nd)} · {t.units.toLocaleString("en-US")} units · risk {money(cur, t.risk)}
        {logged ? ` · logged ${fmtZone(logged.getTime(), SYD)} Sydney` : ""}
      </p>
      <div className="mt-3 flex flex-wrap gap-2">
        <input
          aria-label={`Exit price for ${t.label}`}
          className="min-h-11 min-w-0 flex-1 rounded-xl border border-line bg-paper px-3 font-mono text-base text-ink"
          inputMode="decimal"
          value={px}
          onChange={(e) => setPx(e.target.value)}
        />
        <button type="button" className="min-h-11 rounded-xl bg-copper px-3 text-sm font-semibold text-copper-ink" onClick={() => {
          const n = Number(px);
          if (!Number.isFinite(n) || n < 0) return;
          onClose(t.id, n);
        }}>
          Close
        </button>
        <button type="button" className="min-h-11 rounded-xl border border-line px-3 text-sm" onClick={() => onCancel(t.id)}>
          Not filled
        </button>
      </div>
    </article>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-panel px-2 py-3">
      <p className="text-xs text-faint">{label}</p>
      <p className="mt-1 font-mono text-sm">{value}</p>
    </div>
  );
}
