import { useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";

import { Banner, PlayCard } from "@/components/zone/play-card";
import { loadContextFn, scanBatchFn, sendAlertFn } from "@/lib/zone/api.server";
import {
  alertLines,
  applyView,
  evaluate,
  limitState,
  type Play,
  type Row,
} from "@/lib/zone/engine";
import {
  DIRS,
  MARKET_NAMES,
  SORTS,
  US_MARKETS,
  buildJobs,
  validTopic,
  type MarketName,
} from "@/lib/zone/markets";
import { type ScanSnap, useDesk } from "@/lib/zone/store";
import { fmtZone, isNyWeekend, nextUsOpen, priceTtlLabel, SYD, zonedParts } from "@/lib/zone/time";

const BATCH = 4;

export function ScanView() {
  const settings = useDesk((s) => s.settings);
  const journal = useDesk((s) => s.journal);
  const scan = useDesk((s) => s.scan);
  const setScan = useDesk((s) => s.setScan);
  const setSetting = useDesk((s) => s.setSetting);
  const setFlash = useDesk((s) => s.setFlash);
  const fmpKey = useDesk((s) => s.fmpKey);
  const scanBatch = useServerFn(scanBatchFn);
  const loadContext = useServerFn(loadContextFn);
  const sendAlert = useServerFn(sendAlertFn);
  const [progress, setProgress] = useState<{ done: number; total: number; label: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const lock = useRef(false);
  const runRef = useRef<() => Promise<void>>(async () => {});

  const rows = useMemo(() => {
    if (!scan) return [] as Row[];
    return withRows(scan.plays, settings, journal, scan.rates, scan.ctx);
  }, [scan, settings, journal]);

  const view = useMemo(() => applyView(rows, settings), [rows, settings]);
  const takes = view.filter((r) => r.tech.length === 0 && r.flt.length === 0);
  const blocked = view.filter((r) => r.tech.length === 0 && r.flt.length > 0);
  const close = view.filter(
    (r) => r.tech.length > 0 && r.play.score >= settings.min_score - 1 && r.play.rr >= settings.min_rr_take - 1,
  );

  async function run() {
    if (lock.current) return;
    const jobsAll = buildJobs(settings);
    if (!jobsAll.length) {
      setFlash("Pick a market or add a symbol first.");
      return;
    }
    setBusy(true);
    lock.current = true;
    const t0 = Date.now();
    setProgress({ done: 0, total: jobsAll.length, label: "Reading the New York session, rates and earnings…" });
    try {
      const ctxPayload = await loadContext({ data: { manual: settings.manual_ev, fmpKey } });
      let jobs = jobsAll;
      let skippedUs = 0;
      if (settings.f_stale && ctxPayload.index && !ctxPayload.index.open) {
        const kept = jobs.filter((j) => !US_MARKETS.includes(j.market as MarketName));
        skippedUs = jobs.length - kept.length;
        jobs = kept;
      }
      const acc: ScanSnap = {
        ts: Date.now(),
        plays: [],
        errors: [],
        n: jobs.length,
        skippedUs,
        secs: 0,
        ctx: { events: ctxPayload.events, status: ctxPayload.status, index: ctxPayload.index },
        rates: ctxPayload.rates,
        hits: 0,
        misses: 0,
        earnOk: ctxPayload.earnOk,
        running: true,
      };
      setScan(acc);
      for (let i = 0; i < jobs.length; i += BATCH) {
        const batch = jobs.slice(i, i + BATCH);
        setProgress({
          done: i,
          total: jobs.length,
          label: batch.map((b) => b.label).join(", "),
        });
        const res = await scanBatch({
          data: {
            jobs: batch,
            maxDist: settings.max_dist,
            minScore: settings.min_score,
            minRr: settings.min_rr_take,
            perInst: settings.per_inst,
            maxSpread: settings.max_spread,
          },
        });
        for (const row of res.results) {
          acc.plays.push(...row.plays);
          if (row.error) acc.errors.push(`${row.sym}: ${row.error}`);
          if (row.cache === "hit") acc.hits += 1;
          else acc.misses += 1;
        }
        acc.earnOk = res.earnOk && acc.earnOk;
        acc.secs = (Date.now() - t0) / 1000;
        setScan({ ...acc, plays: [...acc.plays], errors: [...acc.errors] });
        setProgress({
          done: Math.min(i + batch.length, jobs.length),
          total: jobs.length,
          label: batch.map((b) => b.label).join(", "),
        });
      }
      acc.running = false;
      acc.secs = (Date.now() - t0) / 1000;
      acc.ts = Date.now();
      setScan({ ...acc, plays: [...acc.plays], errors: [...acc.errors] });
      if (settings.alerts_on && validTopic(settings.ntfy_topic)) {
        await maybeAlert(acc, settings, journal, sendAlert, setFlash);
      }
    } catch (e) {
      setFlash(e instanceof Error ? e.message : "The scan could not reach the price feed.");
    } finally {
      lock.current = false;
      setBusy(false);
      setProgress(null);
    }
  }

  runRef.current = run;

  useEffect(() => {
    if (!settings.auto) return;
    const id = window.setInterval(() => {
      void runRef.current();
    }, 60 * 60 * 1000);
    return () => window.clearInterval(id);
  }, [settings.auto]);

  const pct = progress && progress.total ? Math.round((progress.done / progress.total) * 100) : 0;
  const openNext = nextUsOpen();

  return (
    <div className="grid gap-4">
      <div className="flex gap-2 overflow-x-auto pb-1">
        {MARKET_NAMES.map((m) => {
          const on = settings.sel.includes(m);
          return (
            <button
              key={m}
              type="button"
              aria-pressed={on}
              className={`min-h-11 shrink-0 rounded-full border px-4 text-sm ${on ? "border-copper bg-copper text-copper-ink" : "border-line bg-panel text-muted"}`}
              onClick={() => {
                const sel = on ? settings.sel.filter((x) => x !== m) : [...settings.sel, m];
                setSetting("sel", sel);
              }}
            >
              {m}
            </button>
          );
        })}
      </div>
      <p className="text-sm text-faint">
        Crypto is the default so a scan stays short. US names are skipped while New York is closed.
        {openNext ? ` Next US open ${fmtZone(openNext.getTime(), SYD)} Sydney.` : ""}
        {isNyWeekend() ? " Weekend clocks are not treated as a live US session." : ""}
      </p>
      <button
        type="button"
        className="min-h-12 rounded-xl bg-copper text-base font-semibold text-copper-ink disabled:opacity-40"
        disabled={busy || (!settings.sel.length && !settings.extras.trim())}
        onClick={() => void run()}
      >
        {busy ? "Scanning…" : "Scan now"}
      </button>
      {progress ? (
        <div>
          <div
            className="h-2 overflow-hidden rounded-full bg-panel"
            role="progressbar"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={pct}
          >
            <div className="h-full bg-copper transition-[width] duration-200" style={{ width: `${pct}%` }} />
          </div>
          <p className="mt-2 text-sm text-muted">
            {progress.done} of {progress.total}
            {progress.label ? ` · ${progress.label}` : ""}
          </p>
          <p className="text-sm text-faint">Four names at a time, with a short pause so Yahoo does not block the scan.</p>
        </div>
      ) : null}
      {busy && !scan?.plays.length ? (
        <div className="grid gap-3" aria-hidden>
          <div className="h-28 animate-pulse rounded-2xl bg-panel" />
          <div className="h-28 animate-pulse rounded-2xl bg-panel" />
        </div>
      ) : null}
      <div className="grid grid-cols-2 gap-2">
        <label className="grid gap-1 text-sm">
          <span className="text-faint">Sort</span>
          <select
            className="min-h-11 rounded-xl border border-line bg-paper px-3 text-ink"
            value={settings.sort_by}
            onChange={(e) => setSetting("sort_by", e.target.value as SettingsSort)}
          >
            {SORTS.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </label>
        <label className="grid gap-1 text-sm">
          <span className="text-faint">Min reward : risk</span>
          <input
            className="min-h-11 rounded-xl border border-line bg-paper px-3 font-mono text-ink"
            type="number"
            min={0}
            max={20}
            step={0.5}
            value={settings.min_rr}
            onChange={(e) => setSetting("min_rr", clampView(Number(e.target.value)))}
          />
        </label>
      </div>
      <div className="flex gap-2">
        {DIRS.map((d) => (
          <button
            key={d}
            type="button"
            aria-pressed={settings.dir_f === d}
            className={`min-h-11 flex-1 rounded-xl border text-sm ${settings.dir_f === d ? "border-copper text-copper" : "border-line text-muted"}`}
            onClick={() => setSetting("dir_f", d)}
          >
            {d}
          </button>
        ))}
      </div>
      <label className="flex min-h-11 items-center justify-between gap-3 text-sm">
        <span>Show close calls</span>
        <input
          type="checkbox"
          className="size-5 accent-copper"
          checked={settings.show_close}
          onChange={(e) => setSetting("show_close", e.target.checked)}
        />
      </label>
      {!scan ? <Banner tone="info">Pick markets and tap Scan now. Prices are delayed.</Banner> : <ScanBody scan={scan} takes={takes} blocked={blocked} close={close} showClose={settings.show_close} />}
    </div>
  );
}

type SettingsSort = (typeof SORTS)[number];

function clampView(n: number) {
  if (!Number.isFinite(n)) return 0;
  return Math.min(20, Math.max(0, n));
}

function ScanBody({
  scan,
  takes,
  blocked,
  close,
  showClose,
}: {
  scan: ScanSnap;
  takes: Row[];
  blocked: Row[];
  close: Row[];
  showClose: boolean;
}) {
  const settings = useDesk((s) => s.settings);
  const journal = useDesk((s) => s.journal);
  const lim = limitState(journal, settings);
  const stale = scan.plays.filter((p) => p.barTs != null && (Date.now() - p.barTs) / 60000 > settings.stale_min);
  const newsMiss = [...new Set(scan.plays.filter((p) => p.newsOk === false).map((p) => p.tkr))];
  return (
    <div className="grid gap-4">
      <p className="text-sm text-faint">
        Last scan {fmtZone(scan.ts, SYD)} Sydney · {scan.n} instruments in {scan.secs.toFixed(0)}s · {scan.hits} from cache, {scan.misses} fresh · prices delayed
      </p>
      <p className="text-sm text-faint">{priceTtlLabel()}</p>
      {scan.skippedUs ? (
        <Banner tone="info">{`Skipped ${scan.skippedUs} US stocks and ETFs because the US cash session is closed. They are scanned again once it opens.`}</Banner>
      ) : null}
      <SessionBanner scan={scan} />
      {lim.halt.length && settings.f_limits ? <Banner tone="bad">{`Trading limits: ${lim.halt.join("; ")}. New signals are held back.`}</Banner> : null}
      {!lim.halt.length && settings.f_limits ? (
        <p className="text-sm text-faint">
          Today {moneyish(lim.cur, lim.dayPnl)} · {lim.openN} of {lim.maxOpen} trades open · open risk {moneyish(lim.cur, lim.openRisk)} of {moneyish(lim.cur, lim.riskCap)}
        </p>
      ) : null}
      <p className="text-sm text-faint">{scan.ctx.status}</p>
      {!scan.earnOk && settings.f_earn ? (
        <Banner tone="warn">The earnings calendar could not be read, so that check was skipped.</Banner>
      ) : null}
      {scan.plays.length > 0 && stale.length >= 0.6 * scan.plays.length ? (
        <Banner tone="warn">{`${stale.length} of ${scan.plays.length} plays use candles older than ${settings.stale_min.toFixed(0)} minutes, so those markets are probably closed.`}</Banner>
      ) : null}
      {newsMiss.length && settings.f_news ? (
        <Banner tone="warn">{`Headlines could not be read for ${newsMiss.slice(0, 8).join(", ")}${newsMiss.length > 8 ? " and more" : ""}.`}</Banner>
      ) : null}
      <section className="grid gap-3">
        <h2 className="text-base font-semibold">Take ({takes.length})</h2>
        {takes.length ? takes.map((r) => <PlayCard key={keyOf(r.play)} row={r} />) : (
          <Banner tone="info">Nothing passes every check right now. That is normal. Waiting is part of the strategy.</Banner>
        )}
      </section>
      {blocked.length ? (
        <section className="grid gap-3">
          <h2 className="text-base font-semibold">Blocked by filters ({blocked.length})</h2>
          <p className="text-sm text-faint">These pass the zone rules but a filter says wait.</p>
          {blocked.map((r) => <PlayCard key={keyOf(r.play)} row={r} />)}
        </section>
      ) : null}
      {showClose ? (
        <section className="grid gap-3">
          <h2 className="text-base font-semibold">Close calls ({close.length})</h2>
          {close.map((r) => <PlayCard key={keyOf(r.play)} row={r} />)}
        </section>
      ) : null}
      {scan.errors.length ? (
        <details className="rounded-xl border border-line">
          <summary className="min-h-11 cursor-pointer px-3 py-3 text-sm">{scan.errors.length} instruments could not load</summary>
          <ul className="grid gap-1 px-3 pb-3 text-sm text-muted">
            {scan.errors.map((e) => (
              <li key={e}>{e}</li>
            ))}
          </ul>
        </details>
      ) : null}
    </div>
  );
}

function SessionBanner({ scan }: { scan: ScanSnap }) {
  const idx = scan.ctx.index;
  const now = Date.now();
  if (!idx) return <Banner tone="info">SPY and QQQ could not be read, so the index check is skipped.</Banner>;
  if (!idx.open) {
    const next = nextUsOpen();
    const weekend = isNyWeekend();
    return (
      <Banner tone="info">
        {weekend
          ? "It is the weekend in New York, so US stocks are not treated as live."
          : "US cash session is closed. Volume, VWAP and the index check use the last session."}
        {next ? ` Next open ${fmtZone(next.getTime(), SYD)} Sydney.` : ""}
      </Banner>
    );
  }
  if (idx.down.length) return <Banner tone="warn">{`${idx.down.join("/")} selling off. Buy signals on US stocks are held back.`}</Banner>;
  if (idx.up.length) return <Banner tone="warn">{`${idx.up.join("/")} spiking. Short signals on US stocks are held back.`}</Banner>;
  const soon = scan.ctx.events
    .map((e) => ({ e, mins: (e.t - now) / 60000 }))
    .filter((x) => x.mins > 15 && x.mins <= 180)
    .sort((a, b) => a.mins - b.mins)[0];
  if (soon) {
    return <Banner tone="warn">{`Coming up: ${soon.e.name} at ${fmtZone(soon.e.t, SYD)} Sydney.`}</Banner>;
  }
  return null;
}

function moneyish(cur: string, v: number) {
  return `${v < 0 ? "-" : ""}${cur}${Math.abs(v).toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
}

function keyOf(p: Play) {
  return `${p.tkr}-${p.side}-${p.prox}`;
}

export function withRows(
  plays: Play[],
  settings: ReturnType<typeof useDesk.getState>["settings"],
  journal: ReturnType<typeof useDesk.getState>["journal"],
  rates: Record<string, number>,
  ctx: ScanSnap["ctx"],
) {
  const lim = limitState(journal, settings);
  const cloned = plays.map((p) => ({ ...p, news: [...p.news], sc: [...p.sc], screen: [...p.screen], earn: [...p.earn] }));
  return evaluate(cloned, settings, ctx, (ccy, acct) => {
    const a = rates[ccy];
    const b = rates[acct];
    if (a == null || !b) return null;
    return a / b;
  }, lim);
}

const SEEN_KEY = "zone-ticket-alerted";

async function maybeAlert(
  scan: ScanSnap,
  settings: ReturnType<typeof useDesk.getState>["settings"],
  journal: ReturnType<typeof useDesk.getState>["journal"],
  sendAlert: (args: { data: { topic: string; title: string; body: string } }) => Promise<unknown>,
  setFlash: (v: string | null) => void,
) {
  const rows = withRows(scan.plays, settings, journal, scan.rates, scan.ctx);
  const takes = applyView(rows, settings).filter((r) => r.tech.length === 0 && r.flt.length === 0);
  const day = zonedParts(new Date(), SYD).ymd;
  let seen = new Set<string>();
  try {
    seen = new Set(JSON.parse(localStorage.getItem(SEEN_KEY) || "[]") as string[]);
  } catch {
    seen = new Set();
  }
  const fresh = takes.filter((r) => !seen.has(`${r.play.tkr}|${r.play.side}|${r.play.prox}|${day}`));
  if (!fresh.length) return;
  try {
    await sendAlert({
      data: {
        topic: settings.ntfy_topic.trim(),
        title: `Zone Ticket: ${fresh.length} TAKE`,
        body: alertLines(fresh),
      },
    });
    for (const r of fresh) seen.add(`${r.play.tkr}|${r.play.side}|${r.play.prox}|${day}`);
    localStorage.setItem(SEEN_KEY, JSON.stringify([...seen].slice(-400)));
    setFlash(`Alert sent for ${fresh.length} play${fresh.length === 1 ? "" : "s"}.`);
  } catch (e) {
    setFlash(e instanceof Error ? `Alert failed: ${e.message}` : "Alert failed.");
  }
}
