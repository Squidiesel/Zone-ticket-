import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";

import { Banner, PlayCard } from "@/components/zone/play-card";
import { withRows } from "@/components/zone/scan-view";
import { loadContextFn, scanBatchFn } from "@/lib/zone/api.server";
import type { Play, ScreenRow } from "@/lib/zone/engine";
import { fmt, limitState } from "@/lib/zone/engine";
import { infer } from "@/lib/zone/markets";
import { useDesk } from "@/lib/zone/store";
import type { Ctx } from "@/lib/zone/engine";

export function TickerView() {
  const settings = useDesk((s) => s.settings);
  const journal = useDesk((s) => s.journal);
  const fmpKey = useDesk((s) => s.fmpKey);
  const setFlash = useDesk((s) => s.setFlash);
  const scanBatch = useServerFn(scanBatchFn);
  const loadContext = useServerFn(loadContextFn);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [view, setView] = useState<{
    label: string;
    price: number | null;
    nd: number;
    screen: ScreenRow[];
    plays: Play[];
    ctx: Ctx;
    rates: Record<string, number>;
    error: string | null;
  } | null>(null);

  async function go(raw: string) {
    const sym = raw.trim().toUpperCase();
    if (!sym) return;
    const [label, kind, market] = infer(sym);
    setBusy(true);
    try {
      const ctxPayload = await loadContext({ data: { manual: settings.manual_ev, fmpKey } });
      const res = await scanBatch({
        data: {
          jobs: [{ sym, label, market, kind }],
          maxDist: settings.max_dist,
          minScore: settings.min_score,
          minRr: settings.min_rr_take,
          perInst: settings.per_inst,
          maxSpread: settings.max_spread,
        },
      });
      const row = res.results[0];
      const px = row?.price ?? row?.plays[0]?.px ?? null;
      const nd = row?.plays[0]?.nd ?? 2;
      setView({
        label,
        price: px,
        nd,
        screen: row?.screen ?? [],
        plays: row?.plays ?? [],
        ctx: { events: ctxPayload.events, status: ctxPayload.status, index: ctxPayload.index },
        rates: ctxPayload.rates,
        error: row?.error ?? null,
      });
    } catch (e) {
      setFlash(e instanceof Error ? e.message : "Could not read that ticker.");
    } finally {
      setBusy(false);
    }
  }

  const lim = limitState(journal, settings);
  const rows = view ? withRows(view.plays, settings, journal, view.rates, view.ctx) : [];

  return (
    <div className="grid gap-4">
      <form
        className="grid gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          void go(text);
        }}
      >
        <label className="grid gap-1 text-sm">
          <span className="text-faint">Ticker</span>
          <input
            className="min-h-12 rounded-xl border border-line bg-paper px-3 font-mono text-base text-ink outline-none focus:border-copper"
            placeholder="NVDA, EURUSD=X, GC=F, BTC-USD"
            value={text}
            onChange={(e) => setText(e.target.value)}
            autoCapitalize="characters"
            autoCorrect="off"
          />
        </label>
        <button type="submit" className="min-h-12 rounded-xl bg-copper font-semibold text-copper-ink disabled:opacity-40" disabled={busy || !text.trim()}>
          {busy ? "Reading…" : "Look up"}
        </button>
      </form>
      {busy ? <div className="h-28 animate-pulse rounded-2xl bg-panel" aria-hidden /> : null}
      {view?.error && !view.plays.length ? <Banner tone="bad">{`Could not get enough data for ${view.label}. ${view.error}`}</Banner> : null}
      {view && view.price != null ? (
        <div className="grid gap-4">
          <div>
            <h2 className="text-xl font-semibold">{view.label}</h2>
            <p className="font-mono text-3xl">{fmt(view.price, view.nd)}</p>
            <p className="text-sm text-faint">Prices are delayed. Confirm on your chart before ordering.</p>
          </div>
          {lim.halt.length && settings.f_limits ? <Banner tone="bad">{lim.halt.join("; ")}</Banner> : null}
          <p className="text-sm text-faint">{view.ctx.status}</p>
          <details className="rounded-xl border border-line" open={view.screen.some((r) => r.ok === false)}>
            <summary className="min-h-11 cursor-pointer px-3 py-3 text-sm font-medium">Screen</summary>
            <ul className="grid gap-2 px-3 pb-3 text-sm">
              {view.screen.map((r) => (
                <li key={r.label}>
                  <span className={r.ok === false ? "text-down" : r.ok ? "text-up" : "text-faint"}>
                    {r.ok == null ? "N/A" : r.ok ? "PASS" : "FAIL"}
                  </span>{" "}
                  {r.label}: <span className="font-mono">{r.value}</span>
                </li>
              ))}
            </ul>
          </details>
          {(["long", "short"] as const).map((side) => {
            const items = rows.filter((r) => r.play.side === side);
            return (
              <section key={side} className="grid gap-3">
                <h3 className="text-base font-semibold">{side === "long" ? "Buy levels" : "Sell short levels"}</h3>
                {items.length ? items.map((r) => <PlayCard key={`${r.play.side}-${r.play.prox}`} row={r} />) : (
                  <Banner tone="info">No zone with a usable target right now.</Banner>
                )}
              </section>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}
